execute as @a[tag=classed,scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:luck_of_the_sea":10}}}}] at @s run function manarune:planeswitch/start
execute as @a[tag=classed,scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:luck_of_the_sea":10}}}}] at @s run tag @s add planewand
execute as @a[scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:luck_of_the_sea":10}}}}] at @s run kill @e[type=fishing_bobber,distance=..5]
execute as @a[tag=classed,scores={UsedWand=1..},tag=planewand] run scoreboard players set @s UsedWand 0
tag @a[tag=planewand] remove planewand

execute as @a[tag=classed,scores={UsedWand=1..,level=10..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:soul_speed":3}}}}] at @s run function manarune:planeswitch/inbetween
execute as @a[tag=classed,scores={UsedWand=1..,level=10..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:soul_speed":3}}}}] at @s run tag @s add inbetweenist
execute as @a[scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:soul_speed":3}}}}] at @s run kill @e[type=fishing_bobber,distance=..5]
execute as @a[tag=classed,scores={UsedWand=1..},tag=inbetweenist] run scoreboard players set @s UsedWand 0
tag @a[tag=inbetweenist] remove inbetweenist