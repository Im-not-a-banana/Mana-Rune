function manarune:wandstuff/levwand/levwand
function manarune:wandstuff/enderwand
function manarune:wandstuff/earthwand
function manarune:wandstuff/firewand
function manarune:wandstuff/icewand/icewand
function manarune:wandstuff/lightningwand/lightningwand
function manarune:wandstuff/sonicwand/sonicwand
function manarune:wandstuff/healingwand/healingwand


function manarune:amulets/manaflow/manaflow
function manarune:amulets/syphoning
function manarune:amulets/mana
function manarune:amulets/combo/combo
function manarune:amulets/archer/explosive_bow/explosivebow
function manarune:amulets/archer/lightning_bow/lightningbow
function manarune:amulets/archer/grapple_bow/grapplebow
function manarune:amulets/archer/poison_bow/poisonbow
function manarune:amulets/archer/lev_bow/levbow
