execute as @a[scores={UsedWand=1..,level=5..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:feather_falling":4}}}}] run effect give @s[tag=!wizard,tag=!cleric,tag=!mana] levitation 1 50 true
execute as @a[scores={UsedWand=1..,level=5..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:feather_falling":4}}}}] run effect give @s[tag=wizard,tag=!mageaura] levitation 1 70 true
execute as @a[scores={UsedWand=1..,level=5..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:feather_falling":4}}}}] run effect give @s[tag=wizard,tag=mageaura] levitation 1 80 true
execute as @a[scores={UsedWand=1..,level=5..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:feather_falling":4}}}}] run effect give @s[tag=cleric] levitation 1 70 true
execute as @a[scores={UsedWand=1..,level=5..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:feather_falling":4}}}}] run effect give @s[tag=mana] levitation 1 70 true
execute as @a[scores={UsedWand=1..,level=5..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:feather_falling":4}}}}] run tag @s add levsound
execute as @a[scores={UsedWand=1..,level=5..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:feather_falling":4}}}}] run tag @s add runlevslow
execute as @a[scores={UsedWand=1..,level=5..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:feather_falling":4}}}}] run schedule function manarune:wandstuff/levwand/levremove 2t append
execute as @a[scores={UsedWand=1..,level=5..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:feather_falling":4}}}}] run schedule function manarune:wandstuff/levwand/levslow 0.8s append
execute as @a[scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:feather_falling":4}}}}] at @s run kill @e[type=fishing_bobber,distance=..5]
execute at @a[tag=levsound] run playsound minecraft:entity.breeze.wind_burst ui @a ~ ~ ~ 1 1 0
tag @a remove levsound
execute as @a[scores={UsedWand=1..,level=5..},tag=runlevslow] run scoreboard players set @s UsedWand 0
