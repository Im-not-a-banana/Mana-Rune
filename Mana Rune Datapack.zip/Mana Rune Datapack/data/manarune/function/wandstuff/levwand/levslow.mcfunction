effect give @a[tag=runlevslow,tag=!wizard,tag=!cleric,tag=!mana] slow_falling 1 1 true
effect give @a[tag=runlevslow,tag=wizard,tag=!mageaura] slow_falling 2 2 true
effect give @a[tag=runlevslow,tag=wizard,tag=mageaura] slow_falling 3 3 true
effect give @a[tag=runlevslow,tag=cleric] slow_falling 2 2 true
effect give @a[tag=runlevslow,tag=mana] slow_falling 2 2 true
tag @a remove runlevslow
