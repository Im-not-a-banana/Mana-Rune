effect clear @a[tag=runlevslow] levitation
