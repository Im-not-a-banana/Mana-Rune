execute as @a[scores={UsedWand=1..,level=3..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:efficiency":10}}}}] at @s run tag @s add earthwand
execute as @a[scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:efficiency":10}}}}] at @s run kill @e[type=fishing_bobber,distance=..5]

execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace grass_block destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace dirt destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace stone destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace granite destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace andesite destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace diorite destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace gravel destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace deepslate destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace tuff destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace dripstone_block destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace pointed_dripstone destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace sand destroy
execute at @a[tag=earthwand,tag=!wizard,tag=!cleric,tag=!mana] run fill ^-1 ^1 ^1 ^1 ^3 ^3 air replace sandstone destroy

execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace grass_block destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace dirt destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace stone destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace granite destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace andesite destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace diorite destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace gravel destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace deepslate destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace tuff destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace dripstone_block destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace pointed_dripstone destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace sand destroy
execute at @a[tag=earthwand,tag=wizard] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace sandstone destroy

execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace grass_block destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace dirt destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace stone destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace granite destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace andesite destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace diorite destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace gravel destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace deepslate destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace tuff destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace dripstone_block destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace pointed_dripstone destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace sand destroy
execute at @a[tag=earthwand,tag=wizard,tag=mageaura] run fill ^-1 ^1 ^1 ^1 ^3 ^5 air replace sandstone destroy

execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace grass_block destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace dirt destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace stone destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace granite destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace andesite destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace diorite destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace gravel destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace deepslate destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace tuff destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace dripstone_block destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace pointed_dripstone destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace sand destroy
execute at @a[tag=earthwand,tag=cleric] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace sandstone destroy

execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace grass_block destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace dirt destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace stone destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace granite destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace andesite destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace diorite destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace gravel destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace deepslate destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace tuff destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace dripstone_block destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace pointed_dripstone destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace sand destroy
execute at @a[tag=earthwand,tag=mana] run fill ^-1 ^1 ^1 ^1 ^3 ^4 air replace sandstone destroy

execute as @a[scores={UsedWand=1..,level=3..},tag=earthwand] run scoreboard players set @s UsedWand 0
tag @a[tag=earthwand] remove earthwand
