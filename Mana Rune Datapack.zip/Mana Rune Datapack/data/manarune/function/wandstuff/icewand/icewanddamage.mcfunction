execute as @e[tag=iced] run damage @s 2 freeze
execute as @e[tag=wiced] run damage @s 3 freeze
execute as @e[tag=mawiced] run damage @s 4 freeze
execute as @e[tag=icewandgo] run schedule function manarune:wandstuff/icewand/icewanddamage 5t
