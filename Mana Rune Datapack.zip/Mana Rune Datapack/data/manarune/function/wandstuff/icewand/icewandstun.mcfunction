execute as @e[tag=icewandgo] at @s run tp @s @s
execute as @e[tag=icewandgo] run schedule function manarune:wandstuff/icewand/icewandstun 1t
