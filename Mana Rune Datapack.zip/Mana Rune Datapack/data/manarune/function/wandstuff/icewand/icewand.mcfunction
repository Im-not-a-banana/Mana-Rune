execute as @a[scores={UsedWand=1..,level=11..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}}] at @s run tag @s[tag=wizard] add wicewand
execute as @a[scores={UsedWand=1..,level=11..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}}] at @s run tag @s[tag=cleric] add wicewand
execute as @a[scores={UsedWand=1..,level=11..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}}] at @s run tag @s[tag=mana] add wicewand
execute as @a[scores={UsedWand=1..,level=11..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}}] at @s run tag @s[tag=!wizard,tag=!cleric,tag=!mana] add icewand
execute as @a[scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}}] at @s run kill @e[type=fishing_bobber,distance=..5]

execute at @a[tag=wizard,scores={level=11..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}}] if entity @e[nbt=!{SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}},type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..15] run particle minecraft:dolphin ~ ~1 ~ 0.7 0.7 0.7 5 4 normal
execute at @a[tag=cleric,scores={level=11..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}}] if entity @e[nbt=!{SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}},type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..15] run particle minecraft:dolphin ~ ~1 ~ 0.7 0.7 0.7 5 4 normal
execute at @a[tag=mana,scores={level=11..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}}] if entity @e[nbt=!{SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}},type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..15] run particle minecraft:dolphin ~ ~1 ~ 0.7 0.7 0.7 5 4 normal
execute at @a[tag=!wizard,tag=!cleric,tag=!mana,scores={level=11..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}}] if entity @e[nbt=!{SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:frost_walker":5}}}},type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..10] run particle minecraft:dolphin ~ ~1 ~ 0.7 0.7 0.7 5 3 normal

execute at @a[tag=wicewand,tag=!mageaura] as @e[type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..15,tag=!wicewand] run tag @s add wiced
execute at @a[tag=wicewand,tag=mageaura] as @e[type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..15,tag=!wicewand] run tag @s add mawiced
execute at @a[tag=wicewand] as @e[type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..15,tag=!wicewand] run tag @s add icewandgo
execute at @a[tag=icewand] as @e[type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..12,tag=!icewand] run tag @s add iced
execute at @a[tag=icewand] as @e[type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..12,tag=!icewand] run tag @s add icewandgo

execute as @a[tag=wicewand] run function manarune:wandstuff/icewand/frames/1
execute as @a[tag=icewand] run function manarune:wandstuff/icewand/frames/1
execute as @a[tag=wicewand] run function manarune:wandstuff/icewand/icewanddamage
execute as @a[tag=icewand] run function manarune:wandstuff/icewand/icewanddamage
execute as @a[tag=wicewand] run function manarune:wandstuff/icewand/icewandstun
execute as @a[tag=icewand] run function manarune:wandstuff/icewand/icewandstun

execute as @a[scores={UsedWand=1..,level=11..},tag=icewand] run scoreboard players set @s UsedWand 0
execute as @a[scores={UsedWand=1..,level=11..},tag=wicewand] run scoreboard players set @s UsedWand 0
tag @a remove icewand
tag @a remove wicewand
