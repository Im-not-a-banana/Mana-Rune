execute at @e[tag=icewandgo] run fill ^ ^2 ^1 ^ ^2 ^-1 ice destroy
execute at @e[tag=icewandgo] run fill ^1 ^2 ^ ^-1 ^2 ^ ice destroy
execute at @e[tag=icewandgo] run playsound minecraft:block.basalt.hit ui @a ~ ~ ~ 1 1 0
schedule function manarune:wandstuff/icewand/frames/4 2t append
