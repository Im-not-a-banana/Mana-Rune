execute at @e[tag=icewandgo] run fill ^ ^3 ^ ^ ^3 ^ air destroy
schedule function manarune:wandstuff/icewand/frames/8 2t append
