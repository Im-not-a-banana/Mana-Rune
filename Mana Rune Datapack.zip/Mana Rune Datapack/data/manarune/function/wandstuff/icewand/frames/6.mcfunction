execute at @e[tag=icewandgo] run fill ^ ^4 ^ ^ ^4 ^ air destroy
schedule function manarune:wandstuff/icewand/frames/7 2t append
