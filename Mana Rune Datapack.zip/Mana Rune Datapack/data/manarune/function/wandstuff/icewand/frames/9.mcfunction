execute at @e[tag=icewandgo] run fill ^ ^1 ^1 ^ ^1 ^-1 air destroy
execute at @e[tag=icewandgo] run fill ^1 ^1 ^ ^-1 ^1 ^ air destroy
schedule function manarune:wandstuff/icewand/frames/10 2t append
