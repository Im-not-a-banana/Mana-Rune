execute at @e[tag=icewandgo] run fill ^ ^4 ^ ^ ^4 ^ ice destroy
execute at @e[tag=icewandgo] run playsound minecraft:block.basalt.hit ui @a ~ ~ ~ 1 1 0
schedule function manarune:wandstuff/icewand/frames/6 24t append
