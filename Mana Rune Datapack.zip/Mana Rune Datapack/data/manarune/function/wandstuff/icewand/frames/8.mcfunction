execute at @e[tag=icewandgo] run fill ^ ^2 ^1 ^ ^2 ^-1 air destroy
execute at @e[tag=icewandgo] run fill ^1 ^2 ^ ^-1 ^2 ^ air destroy
schedule function manarune:wandstuff/icewand/frames/9 2t append
