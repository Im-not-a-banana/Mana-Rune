execute at @e[tag=icewandgo] run fill ^1 ^ ^1 ^-1 ^ ^-1 air destroy
tag @e[tag=iced] remove iced
tag @e[tag=wiced] remove wiced
tag @e[tag=icewandgo] remove icewandgo
