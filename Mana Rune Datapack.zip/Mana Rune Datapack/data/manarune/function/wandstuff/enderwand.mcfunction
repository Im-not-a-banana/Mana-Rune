execute as @a[scores={UsedWand=1..,level=7..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:luck_of_the_sea":6}}}}] at @s run tp @s[tag=!wizard,tag=!cleric,tag=!mana] ^ ^ ^50
execute as @a[scores={UsedWand=1..,level=7..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:luck_of_the_sea":6}}}}] at @s run tp @s[tag=wizard,tag=!mageaura] ^ ^ ^60
execute as @a[scores={UsedWand=1..,level=7..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:luck_of_the_sea":6}}}}] at @s run tp @s[tag=wizard,tag=mageaura] ^ ^ ^70
execute as @a[scores={UsedWand=1..,level=7..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:luck_of_the_sea":6}}}}] at @s run tp @s[tag=cleric] ^ ^ ^60
execute as @a[scores={UsedWand=1..,level=7..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:luck_of_the_sea":6}}}}] at @s run tp @s[tag=mana] ^ ^ ^60
execute as @a[scores={UsedWand=1..,level=7..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:luck_of_the_sea":6}}}}] at @s run tag @s add enderwand
execute as @a[scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:luck_of_the_sea":6}}}}] at @s run kill @e[type=fishing_bobber,distance=..5]
execute at @a[tag=enderwand] run playsound minecraft:entity.player.teleport ui @a ~ ~ ~ 10 1 0

execute as @a[scores={UsedWand=1..,level=7..},tag=enderwand] run scoreboard players set @s UsedWand 0
tag @a[tag=enderwand] remove enderwand
