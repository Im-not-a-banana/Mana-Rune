execute unless entity @a[tag=masonicboomer] run damage @s 10 sonic_boom
execute if entity @a[tag=masonicboomer] run damage @s 15 sonic_boom
tag @a[tag=masonicboomer] remove masonicboomer
