execute as @a[scores={UsedWand=1..,level=13..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:sharpness":6}}}}] run tag @s[tag=wizard] add sonicboomer
execute as @a[scores={UsedWand=1..,level=13..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:sharpness":6}}}}] run tag @s[tag=wizard,tag=mageaura] add masonicboomer
execute as @a[scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:sharpness":6}}}}] at @s run kill @e[type=fishing_bobber,distance=..5]
execute as @a[tag=sonicboomer] run scoreboard players set sonicdistance sonicraycast 15
execute as @a[tag=sonicboomer,scores={UsedWand=1..,level=13..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:sharpness":6}}}}] at @s positioned ~ ~1.5 ~ run function manarune:wandstuff/sonicwand/sonicraycast
execute as @a[tag=sonicboomer] at @s run playsound entity.warden.sonic_boom ui @s ~ ~ ~ 100 1 0
scoreboard players set @a[tag=sonicboomer] UsedWand 0
tag @a[tag=sonicboomer] remove sonicboomer
