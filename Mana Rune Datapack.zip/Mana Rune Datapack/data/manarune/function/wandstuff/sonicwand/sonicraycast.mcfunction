scoreboard players operation sonicdistance sonicraycast -= sonicstepdecrease sonicraycast
execute unless block ~ ~ ~ #air positioned ~ ~ ~ run scoreboard players set sonicdistance sonicraycast 0
execute as @e[type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..2,tag=!sonicboomer] at @s run function manarune:wandstuff/sonicwand/entity
execute as @e[type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..2,tag=!sonicboomer] at @s run scoreboard players set sonicdistance sonicraycast 0
execute if score sonicdistance sonicraycast matches 1..15 positioned ^ ^ ^1 as @s run function manarune:wandstuff/sonicwand/sonicraycast
particle sonic_boom ~ ~ ~ 0 0 0 0 1 normal
