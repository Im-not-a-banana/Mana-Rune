execute as @a[scores={UsedWand=1..,level=15..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:protection":5}}}}] run tag @s[tag=cleric] add protected
execute as @a[scores={UsedWand=1..,level=15..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:protection":5}}}}] run tag @s[tag=cleric] add protquick
execute as @a[scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:protection":5}}}}] at @s run kill @e[type=fishing_bobber,distance=..5]
execute as @a[scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:protection":5}}}},tag=protquick] at @s run schedule function manarune:wandstuff/healingwand/healingwandend 5s append
execute at @a[tag=protquick] run summon marker ~ ~ ~ {Tags:["pc"]}
execute as @e[type=marker,tag=pc] at @s run tp @s ~ ~ ~ ~50 ~
execute at @e[type=marker,tag=pc] run particle heart ^ ^ ^5 0 0 0 0.1 1 normal
execute at @e[type=marker,tag=pc] run particle heart ^ ^ ^-5 0 0 0 0.1 1 normal
execute at @a[tag=protected] run tp @e[type=marker,tag=pc,limit=1,sort=nearest] ~ ~ ~
execute at @a[tag=protected] run effect give @a[distance=..5,tag=!regened] regeneration 10 7 true
execute at @a[tag=protected] run tag @a[tag=!regened,distance=..5] add regened
scoreboard players set @a[tag=protquick] UsedWand 0
tag @a remove protquick
