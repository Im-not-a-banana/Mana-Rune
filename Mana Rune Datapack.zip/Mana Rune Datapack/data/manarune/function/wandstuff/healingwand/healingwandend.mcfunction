kill @e[type=marker,tag=pc]
tag @a remove protected
effect clear @a[tag=regened] regeneration
tag @a[tag=regened] remove regened
