execute at @e[type=armor_stand,tag=lwbcenter] run particle minecraft:small_gust ~ ~30 ~ 0.5 30 0.5 0 250
schedule function manarune:wandstuff/lightningwand/lwblockanim/2lwb 2s
