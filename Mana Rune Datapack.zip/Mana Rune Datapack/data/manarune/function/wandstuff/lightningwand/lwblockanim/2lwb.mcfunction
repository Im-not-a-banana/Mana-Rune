execute at @e[type=armor_stand,tag=lwbcenter] run particle minecraft:gust_emitter_small ~ ~30 ~ 0.3 30 0.3 0 500
execute at @e[type=armor_stand,tag=lwbcenter] run summon lightning_bolt
execute at @e[type=armor_stand,tag=lwbcenter] as @a[tag=wlwb] run summon tnt ~ ~ ~ {explosion_power:17,fuse:0}
execute at @e[type=armor_stand,tag=lwbcenter] as @a[tag=mawlwb] run summon tnt ~ ~ ~ {explosion_power:19,fuse:0}
kill @e[type=armor_stand,tag=lwbcenter]
tag @a remove wlwb
