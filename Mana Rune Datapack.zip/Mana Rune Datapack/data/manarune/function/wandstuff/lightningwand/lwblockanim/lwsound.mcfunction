execute at @e[type=armor_stand,tag=lwbcenter] run playsound entity.lightning_bolt.thunder ui @a ~ ~ ~ 3 0.05 0
execute as @e[type=armor_stand,tag=lwbcenter] run schedule function manarune:wandstuff/lightningwand/lwblockanim/lwsound 6t
