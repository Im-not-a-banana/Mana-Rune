scoreboard players set distance raycast 0
summon armor_stand ~ ~ ~ {Tags:["lwbcenter"],Invisible:1b,NoGravity:1b}
schedule function manarune:wandstuff/lightningwand/lwblockanim/partstart 4s append
tag @s add wlwb
tag @s[tag=mageaura] add mawlwb
function manarune:wandstuff/lightningwand/lwblockanim/lwsound
