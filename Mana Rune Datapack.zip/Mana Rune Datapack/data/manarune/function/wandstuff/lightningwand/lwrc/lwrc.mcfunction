scoreboard players operation distance raycast -= stepdecrease raycast
execute unless block ~ ~ ~ #air positioned ~ ~ ~ run function manarune:wandstuff/lightningwand/lwrc/block
execute as @e[type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..2,tag=!wlightning] at @s run function manarune:wandstuff/lightningwand/lwrc/entity
execute as @e[type=!item,type=!#minecraft:boat,type=!#minecraft:arrows,type=!armor_stand,type=!item_frame,type=!glow_item_frame,type=!minecart,distance=..2,tag=!wlightning] at @s run scoreboard players set distance raycast 0
execute if score distance raycast matches 1..150 positioned ^ ^ ^0.1 as @s run function manarune:wandstuff/lightningwand/lwrc/lwrc
particle electric_spark ~ ~ ~ 0 0 0 0 10 normal
