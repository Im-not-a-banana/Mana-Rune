particle ash ~ ~ ~ 1 1 1 10 50
particle white_ash ~ ~ ~ 1 1 1 10 50
particle minecraft:crit ~ ~ ~ 0 0 0 1 50
particle electric_spark ~ ~ ~ 1 1 1 0 80
particle block{block_state:{Name:light,Properties:{level:"15"}}} ~ ~ ~ 0 0 0 1 100
summon lightning_bolt
summon lightning_bolt
execute if entity @a[tag=mawlightning] run damage @s 24 lightning_bolt
execute unless entity @a[tag=wlightning] run damage @s 20 lightning_bolt
tag @a[tag=mawlightning] remove mawlightning
