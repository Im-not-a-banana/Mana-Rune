execute as @a[scores={UsedWand=1..,level=15..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:sharpness":10}}}}] run tag @s[tag=wizard] add wlightning
execute as @a[scores={UsedWand=1..,level=15..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:sharpness":10}}}}] run tag @s[tag=wizard,tag=mageaura] add mawlightning
execute as @a[scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:sharpness":10}}}}] at @s run kill @e[type=fishing_bobber,distance=..5]
execute as @a[tag=wlightning] run scoreboard players set distance raycast 150
execute as @a[scores={UsedWand=1..,level=15..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:sharpness":10}}}},tag=wlightning] at @s positioned ~ ~1.5 ~ run function manarune:wandstuff/lightningwand/lwrc/lwrc
scoreboard players set @a[tag=wlightning] UsedWand 0
tag @a[tag=wlightning] remove wlightning

execute as @e[type=armor_stand,tag=lwbcenter] at @s run tp @s ~ ~ ~ ~4 ~
execute as @e[type=armor_stand,tag=lwbcenter] at @s run particle minecraft:end_rod ^ ^1 ^7 0.1 0.1 0.1 0 10
execute as @e[type=armor_stand,tag=lwbcenter] at @s run particle minecraft:gust_emitter_small ~ ~ ~ 0.5 0 0.5 0 1
