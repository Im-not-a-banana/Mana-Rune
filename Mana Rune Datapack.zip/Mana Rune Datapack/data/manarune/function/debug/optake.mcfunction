tag @s remove acolyte
tag @s remove cleric
tag @s remove archer
tag @s remove warrior
tag @s remove wizard
tag @s remove classed
scoreboard players set @s xpforlevel 0
xp set @s 0 points
xp set @s 0 levels
tellraw @s 'Takes all levels, XP, and classes.'
