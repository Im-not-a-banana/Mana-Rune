give @s fishing_rod[enchantments={"minecraft:mending":9}]
give @s diamond[enchantments={"minecraft:sharpness":7}]
give @s diamond[enchantments={"minecraft:lure":1}]
give @s diamond[enchantments={"minecraft:lure":3}]
give @s diamond[enchantments={"minecraft:lure":5}]
give @s diamond[enchantments={"minecraft:mending":1}]
tellraw @s 'Gives all amulets.'
