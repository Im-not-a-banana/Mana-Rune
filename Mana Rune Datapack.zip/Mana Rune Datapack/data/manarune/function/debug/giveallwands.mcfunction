give @s fishing_rod[enchantments={"minecraft:sharpness":9}]
give @s fishing_rod[enchantments={"minecraft:fire_aspect":1}]
give @s fishing_rod[enchantments={"minecraft:feather_falling":1}]
give @s fishing_rod[enchantments={"minecraft:luck_of_the_sea":5}]
give @s fishing_rod[enchantments={"minecraft:frost_walker":1}]
give @s fishing_rod[enchantments={"minecraft:efficiency":9}]
give @s fishing_rod[enchantments={"minecraft:sharpness":5}]
give @s fishing_rod[enchantments={"minecraft:protection":5}]
tellraw @s 'Gives all normal wands.'
