tag @s add acolyte
tag @s add cleric
tag @s add archer
tag @s add warrior
tag @s add wizard
tag @s add classed
execute at @s run summon experience_orb ~ ~ ~ {Value:10000}
execute at @s run summon experience_orb ~ ~ ~ {Value:10000}
execute at @s run summon experience_orb ~ ~ ~ {Value:10000}
execute at @s run summon experience_orb ~ ~ ~ {Value:10000}
execute at @s run summon experience_orb ~ ~ ~ {Value:10000}
execute at @s run summon experience_orb ~ ~ ~ {Value:10000}
tellraw @s 'Gives all levels, XP, and classes to test things easlily.'
