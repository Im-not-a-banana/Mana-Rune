execute as @s run function manarune:debug/giveallamulets
execute as @s run function manarune:debug/giveallwands
execute as @s run function manarune:debug/opgive
tellraw @s 'Gives all wands, amulets, and classes.'
