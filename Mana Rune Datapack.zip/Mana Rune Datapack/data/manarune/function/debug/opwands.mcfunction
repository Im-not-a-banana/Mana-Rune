give @s fishing_rod[enchantments={"minecraft:sharpness":10}]
give @s fishing_rod[enchantments={"minecraft:fire_aspect":5}]
give @s fishing_rod[enchantments={"minecraft:feather_falling":4}]
give @s fishing_rod[enchantments={"minecraft:luck_of_the_sea":6}]
give @s fishing_rod[enchantments={"minecraft:frost_walker":5}]
give @s fishing_rod[enchantments={"minecraft:efficiency":10}]
give @s fishing_rod[enchantments={"minecraft:sharpness":6}]
give @s fishing_rod[enchantments={"minecraft:protection":5}]
tellraw @s 'Gives all wands without cooldowns. Have fun :)'
