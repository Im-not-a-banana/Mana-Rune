function manarune:glowclear
execute as @a if items entity @s armor.head minecraft:iron_helmet[custom_data={partyhelmet:true}] run execute as @a if items entity @s container.* minecraft:iron_helmet[custom_data={partyhelmet:true}] run effect give @s glowing 1 1 true
execute as @a if items entity @s armor.head minecraft:iron_helmet[custom_data={partyhelmet:true}] run effect give @s glowing 1 1 true
