ride @s dismount
execute at @s run tp @e[type=pig,tag=seat,limit=1,sort=nearest,distance=..0.3] ~ -100000 ~
effect clear @s[scores={level=2..}] regeneration
execute at @s[scores={level=1..}] facing ^ ^ ^1 run summon pig ~ ~-0.9 ~ {equipment:{saddle:{id:saddle,count:1}},NoAI:1b,Invulnerable:1b,active_effects:[{id:invisibility,duration:-1,amplifier:1,show_particles:0b}],attributes:[{id:max_health,base:1f}],Silent:1b,Team:nocolentities,Tags:["seat"]}
ride @s[scores={level=1..}] mount @n[type=pig,tag=seat]
effect give @s[scores={level=2..7}] regeneration infinite 0 true
effect give @s[scores={level=8..13}] regeneration infinite 1 true
effect give @s[scores={level=14..}] regeneration infinite 2 true
playsound minecraft:entity.pig.saddle master @s ~ ~ ~ 1 1 0
scoreboard players set @s[scores={level=1..}] sneaktrack 0
