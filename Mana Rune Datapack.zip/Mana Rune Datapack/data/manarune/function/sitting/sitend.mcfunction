ride @s dismount
execute at @s run tp @e[type=pig,tag=seat,limit=1,sort=nearest] ~ -100000 ~
effect clear @s[scores={level=2..}] regeneration

