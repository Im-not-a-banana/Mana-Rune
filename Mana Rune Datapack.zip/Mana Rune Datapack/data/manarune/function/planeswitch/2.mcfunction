effect give @a[tag=planeswitch] blindness 4
schedule function manarune:planeswitch/end 3s append