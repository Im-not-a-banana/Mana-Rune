execute as @s[scores={level=10..},tag=classed,nbt={Dimension:"manarune:inbetween"}] run tag @s add overi
execute as @s[scores={level=10..},tag=classed,nbt={Dimension:"manarune:etherealplane"}] run tag @s add inbetween
execute as @s[scores={level=10..},tag=classed,nbt={Dimension:"minecraft:overworld"}] run tag @s add inbetween

execute as @s[tag=overi] in overworld run spreadplayers ~ ~ 0 1 false @s
execute as @s[tag=inbetween] in manarune:inbetween run spreadplayers ~ ~ 0 1 false @s
tag @s[tag=overi,nbt={Dimension:"minecraft:overworld"}] remove overi
tag @s[tag=inbetween,nbt={Dimension:"manarune:inbetween"}] remove inbetween
execute as @s[tag=overi,nbt={Dimension:"manarune:inbetween"}] in minecraft:overworld run tp @s ~ 63 ~
execute at @s[tag=overi] run setblock ~ 62 ~ grass_block
execute as @s[tag=inbetween,nbt={Dimension:"minecraft:overworld"}] in manarune:inbetween run tp @s ~ 63 ~
execute as @s[tag=inbetween,nbt={Dimension:"manarune:etherealplane"}] in manarune:inbetween run tp @s ~ 63 ~
execute at @s[tag=inbetween] run setblock ~ 62 ~ grass_block

execute at @s run playsound minecraft:block.end_portal.spawn master @s ~ ~ ~ 100 0.5 0
execute at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 100 0.7 0
execute at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 100 1 0

tag @a[tag=overi] remove overi
tag @a[tag=inbetween] remove inbetween
