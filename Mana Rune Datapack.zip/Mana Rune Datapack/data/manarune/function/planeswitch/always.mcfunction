execute at @a[tag=planeswitch] run particle minecraft:cloud ~ ~2 ~ 1 1 1 0 10 normal
execute if entity @a[tag=planeswitch] run schedule function manarune:planeswitch/always 2t
