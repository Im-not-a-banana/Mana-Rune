execute as @s[tag=classed] run tag @s add planeswitch
execute as @s[tag=classed] run effect give @s levitation 6 1
execute as @s[tag=classed] run effect give @s darkness 3 1 true
execute as @s[tag=classed] run playsound minecraft:test master @s ~ ~ ~ 1 1 0
execute as @s[tag=classed] run playsound minecraft:test master @s ~ ~ ~ 10 0.3 0
execute as @s[tag=classed] run playsound minecraft:planeswitch master @s ~ ~ ~ 1 0.3 0
execute as @s[tag=classed] run schedule function manarune:planeswitch/2 2s append
execute as @s[tag=classed] run function manarune:planeswitch/always
