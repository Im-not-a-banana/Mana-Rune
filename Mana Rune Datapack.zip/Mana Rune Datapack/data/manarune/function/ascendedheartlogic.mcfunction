execute as @a store result score @s maxhp run attribute @s minecraft:max_health base get

execute as @s[scores={maxhp=20}] run attribute @s max_health base set 22
execute as @s[scores={maxhp=22}] run attribute @s max_health base set 24
execute as @s[scores={maxhp=24}] run attribute @s max_health base set 26
execute as @s[scores={maxhp=26}] run attribute @s max_health base set 28
execute as @s[scores={maxhp=28}] run attribute @s max_health base set 30
execute as @s[scores={maxhp=30}] run attribute @s max_health base set 32
execute as @s[scores={maxhp=32}] run attribute @s max_health base set 34
execute as @s[scores={maxhp=34}] run attribute @s max_health base set 36
execute as @s[scores={maxhp=36}] run attribute @s max_health base set 38
execute as @s[scores={maxhp=38}] run attribute @s max_health base set 40
clear @s[scores={maxhp=..39}] nether_star 1

advancement revoke @s only manarune:manarune/nondisplayadvancements/ascendedheart
