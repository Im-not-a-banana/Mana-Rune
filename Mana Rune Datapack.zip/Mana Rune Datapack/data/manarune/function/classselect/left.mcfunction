execute as @s run scoreboard players add @s ClassConfirm 1
tag @s remove warned