execute as @e[type=interaction,tag=classselect] at @s unless entity @a[scores={level=4..},tag=selecting,distance=..2] run kill @s
execute as @e[type=item_display,tag=classimage] at @s unless entity @a[scores={level=4..},tag=selecting,distance=..3] run kill @s
execute as @a[scores={level=4..},nbt={SelectedItem:{id:"minecraft:diamond",components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}},tag=!selecting] at @s run summon interaction ~ ~1.5 ~ {Tags:["classselect"],width:0.5f,height:0.5f}
execute as @a[scores={level=4..},nbt={SelectedItem:{id:"minecraft:diamond",components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}},tag=!selecting] at @s run summon item_display ^ ^ ^0.5 {item:{id:"minecraft:diamond",count:1,components:{"minecraft:enchantments":{"minecraft:unbreaking":4}}},transformation:{left_rotation:[0.70710677f,0f,0f,0.70710677f],scale:[2f,2f,2f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f]},Tags:["classimage"]}
execute as @a[scores={level=4..},nbt={SelectedItem:{id:"minecraft:diamond",components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}},tag=!selecting] run tag @s add selecting
execute as @a[scores={level=4..},nbt=!{SelectedItem:{id:"minecraft:diamond",components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}},tag=selecting] at @s run tag @s remove selecting
execute as @a[scores={level=4..},tag=selecting] at @s unless entity @e[type=interaction,distance=..2,tag=classselect] run tag @s remove selecting
execute as @a[scores={level=4..},tag=selecting] at @s unless entity @e[type=item_display,distance=..3,tag=classimage] run tag @s remove selecting

execute as @a[scores={level=4..},tag=selecting] at @s run tp @e[type=interaction,tag=classselect,limit=1,sort=nearest] ~ ~1.5 ~
execute as @a[scores={level=4..},tag=selecting] at @s anchored eyes run tp @e[type=item_display,tag=classimage,limit=1,sort=nearest] ^ ^ ^0.5 facing ~ ~1.5 ~

execute as @e[type=interaction,tag=classselect] on target run function manarune:classselect/right
execute as @e[type=interaction,tag=classselect] run data remove entity @s interaction
execute as @e[type=interaction,tag=classselect] on attacker run function manarune:classselect/left
execute as @e[type=interaction,tag=classselect] run data remove entity @s attack

scoreboard players set @a[scores={level=4..},tag=!selecting] ClassConfirm 0
scoreboard players set @a[scores={level=4..},tag=!selecting] ClassSelect 0

title @a[scores={level=4..,ClassSelect=1},tag=!warned,tag=selecting] title '§6Acolyte'
execute as @a[scores={level=4..,ClassSelect=1}] run scoreboard players add @s ClassSelect 1
title @a[scores={level=4..,ClassSelect=3},tag=!warned,tag=selecting] title '§3Archer'
execute as @a[scores={level=4..,ClassSelect=3}] run scoreboard players add @s ClassSelect 1
title @a[scores={level=4..,ClassSelect=5},tag=!warned,tag=selecting] title '§5Cleric'
execute as @a[scores={level=4..,ClassSelect=5}] run scoreboard players add @s ClassSelect 1
title @a[scores={level=4..,ClassSelect=7},tag=!warned,tag=selecting] title '§4Warrior'
execute as @a[scores={level=4..,ClassSelect=7}] run scoreboard players add @s ClassSelect 1
title @a[scores={level=4..,ClassSelect=9},tag=!warned,tag=selecting] title '§dWizard'
execute as @a[scores={level=4..,ClassSelect=9}] run scoreboard players add @s ClassSelect 1
title @a[scores={level=4..,ClassSelect=-1},tag=!warned,tag=selecting] title 'Unclassed'
execute as @a[scores={level=4..,ClassSelect=-1}] run scoreboard players add @s ClassSelect 1

tellraw @a[scores={level=4..,ClassConfirm=1,ClassSelect=1..},tag=!warned] '§aPlease left click to confirm or right click to deselect.'
tellraw @a[scores={level=4..,ClassConfirm=1,ClassSelect=-1..0},tag=!warned] '§7Are you sure you would like to switch to Unclassed? Please left click to confirm or right click to deselect.'
tag @a[scores={level=4..,ClassConfirm=1,ClassSelect=-1..},tag=!warned] add warned

execute as @a[scores={level=4..,ClassConfirm=2}] run tag @s remove acolyte
execute as @a[scores={level=4..,ClassConfirm=2}] run tag @s remove archer
execute as @a[scores={level=4..,ClassConfirm=2}] run tag @s remove cleric
execute as @a[scores={level=4..,ClassConfirm=2}] run tag @s remove warrior
execute as @a[scores={level=4..,ClassConfirm=2}] run tag @s remove wizard
execute as @a[scores={level=4..,ClassConfirm=2}] run tag @s remove classed

execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=1..2}] run tag @s add acolyte
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=1..2}] run tellraw @s '§6Acolyte Selected'
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=3..4}] run tag @s add archer
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=3..4}] run tellraw @s '§3Archer Selected'
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=5..6}] run tag @s add cleric
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=5..6}] run tellraw @s '§5Cleric Selected'
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=7..8}] run tag @s add warrior
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=7..8}] run tellraw @s '§4Warrior Selected'
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=9..10}] run tag @s add wizard
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=9..10}] run tellraw @s '§dWizard Selected'
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=-1..0}] run tellraw @s 'Unclassed Selected'

execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=-1..}] run clear @s diamond[enchantments={"minecraft:unbreaking":3}] 1
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=1..}] run tag @s add classed
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=-1..}] run tag @s remove selecting
execute as @a[scores={level=4..,ClassConfirm=2,ClassSelect=-1..}] run scoreboard players set @s ClassConfirm 0
