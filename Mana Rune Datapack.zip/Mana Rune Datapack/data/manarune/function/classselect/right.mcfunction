execute as @s[scores={ClassSelect=0..9}] run scoreboard players add @s ClassSelect 1
execute as @s[scores={ClassSelect=10}] run scoreboard players set @s ClassSelect -1
execute as @s run scoreboard players set @s ClassConfirm 0
tag @s remove warned