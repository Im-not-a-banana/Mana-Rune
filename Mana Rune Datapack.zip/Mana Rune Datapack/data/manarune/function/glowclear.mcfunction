execute as @a if items entity @s container.* minecraft:iron_helmet[custom_data={partyhelmet:true}] run effect clear @s glowing
execute as @a if items entity @s armor.head minecraft:iron_helmet[custom_data={partyhelmet:true}] run effect clear @s glowing
