#wands wizard
execute as @a[tag=wizard,scores={level=3..}] run recipe give @s manarune:wands/earth
execute as @a[tag=wizard,scores={level=5..}] run recipe give @s manarune:wands/levitation
execute as @a[tag=wizard,scores={level=7..}] run recipe give @s manarune:wands/ender
execute as @a[tag=wizard,scores={level=10..}] run recipe give @s manarune:wands/fire
execute as @a[tag=wizard,scores={level=11..}] run recipe give @s manarune:wands/ice
execute as @a[tag=wizard,scores={level=13..}] run recipe give @s manarune:wands/sonic
execute as @a[tag=wizard,scores={level=15..}] run recipe give @s manarune:wands/lightning
execute as @a[tag=wizard,scores={level=10..}] run recipe give @s manarune:amulets/mage

#wands cleric
execute as @a[tag=cleric,scores={level=3..}] run recipe give @s manarune:wands/earth
execute as @a[tag=cleric,scores={level=5..}] run recipe give @s manarune:wands/levitation
execute as @a[tag=cleric,scores={level=7..}] run recipe give @s manarune:wands/ender
execute as @a[tag=cleric,scores={level=10..}] run recipe give @s manarune:wands/fire
execute as @a[tag=cleric,scores={level=11..}] run recipe give @s manarune:wands/ice

#amulets acolyte
execute as @a[tag=acolyte,scores={level=12..}] run recipe give @s manarune:amulets/mana
execute as @a[tag=acolyte,scores={level=12..}] run recipe give @s manarune:amulets/syphoning
execute as @a[tag=acolyte,scores={level=15..}] run recipe give @s manarune:amulets/manaflow
