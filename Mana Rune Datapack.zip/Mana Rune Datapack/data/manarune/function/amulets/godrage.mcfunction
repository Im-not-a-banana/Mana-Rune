advancement revoke @s only manarune:manarune/nondisplayadvancements/godragehit
execute as @s[scores={level=15..},tag=warrior] if items entity @s weapon.offhand diamond[enchantments={"minecraft:aqua_affinity":2}] store result score @s godrage run random value 1..5
execute as @s[tag=warrior,scores={level=15..,godrage=4}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:aqua_affinity":2}] run tag @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] add godblooded
execute at @s[tag=warrior,scores={level=15..,godrage=4}] as @e[tag=godblooded,distance=..5] run damage @s 25 player_attack by @a[tag=warrior,scores={level=15..,godrage=4},sort=nearest,limit=1,distance=..0.1]
execute as @s[tag=warrior,scores={level=15..,godrage=4}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:aqua_affinity":2}] at @e[tag=godblooded,distance=..5] run particle block{block_state:{Name:amethyst_block}} ~ ~1 ~ 0.7 0.7 0.7 0 30 normal
execute as @s[tag=warrior,scores={level=15..,godrage=4}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:aqua_affinity":2}] at @e[tag=godblooded,distance=..5] run particle dust{color:[0.68,0.49,0.87],scale:3} ~ ~1 ~ 1 1 1 10 10
execute as @s[tag=warrior,scores={level=15..,godrage=4}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:aqua_affinity":2}] at @e[tag=godblooded,distance=..5] run particle dust_pillar{block_state:{Name:amethyst_block}} ~ ~1 ~ 0.1 0.1 0.1 0.1 10
tag @e[tag=godblooded] remove godblooded
