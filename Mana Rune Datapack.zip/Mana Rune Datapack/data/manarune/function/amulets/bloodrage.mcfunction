advancement revoke @s only manarune:manarune/nondisplayadvancements/bloodragehit
execute as @s[scores={damagetrack=300..}] unless items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":8}] run scoreboard players set @s damagetrack 0
execute as @s[tag=warrior,scores={damagetrack=300..998,level=14..}] run scoreboard players set @s damagetrack 999
execute as @s[tag=warrior,scores={damagetrack=1000..,level=14..}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":8}] run tag @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] add blooded
execute at @s[tag=warrior,scores={damagetrack=1000..,level=14..}] as @e[tag=blooded,distance=..5] run damage @s 20 player_attack by @a[tag=warrior,scores={damagetrack=1000..,level=14..},sort=nearest,limit=1,distance=..0.1]
execute as @s[tag=warrior,scores={damagetrack=1000..,level=14..}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":8}] at @e[tag=blooded,distance=..5] run particle block{block_state:{Name:redstone_block}} ~ ~1 ~ 0.7 0.7 0.7 0 30 normal
execute as @s[tag=warrior,scores={damagetrack=1000..,level=14..}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":8}] at @e[tag=blooded,distance=..5] run particle dust{color:[0.71,0.23,0.23],scale:3} ~ ~1 ~ 1 1 1 10 10
execute as @s[tag=warrior,scores={damagetrack=1000..,level=14..}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":8}] at @e[tag=blooded,distance=..5] run particle dust_pillar{block_state:{Name:redstone_block}} ~ ~1 ~ 0.1 0.1 0.1 0.1 10
execute as @s[tag=warrior,scores={damagetrack=1000..,level=14..}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":8}] at @e[tag=blooded,distance=..5] run particle flash{color:[0.7f,0.1f,0.1f,1f]} ~ ~1 ~ 0 0 0 0 1
execute as @s[tag=warrior,scores={damagetrack=1000..,level=14..}] run scoreboard players set @s damagetrack 0
tag @e[tag=blooded] remove blooded
