execute as @a[scores={level=6..}] if items entity @s weapon.offhand diamond[enchantments={"minecraft:unbreaking":15}] if items entity @s weapon.mainhand bow run enchant @s manarune:grapplebow
execute as @a[scores={level=6..}] if items entity @s weapon.offhand diamond[enchantments={"minecraft:unbreaking":15}] if items entity @s weapon.mainhand bow run enchant @s manarune:grapplebow
execute as @a unless items entity @s weapon.offhand diamond[enchantments={"minecraft:unbreaking":15}] if items entity @s container.* bow run function manarune:amulets/archer/grapple_bow/grappleremove
