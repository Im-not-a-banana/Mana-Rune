execute as @a[tag=archer,scores={level=12..}] if items entity @s weapon.offhand diamond[enchantments={"minecraft:unbreaking":13}] if items entity @s weapon.mainhand bow run enchant @s manarune:lev_bow
execute as @a[tag=acolyte,scores={level=12..}] if items entity @s weapon.offhand diamond[enchantments={"minecraft:unbreaking":13}] if items entity @s weapon.mainhand bow run enchant @s manarune:lev_bow
execute as @a unless items entity @s weapon.offhand diamond[enchantments={"minecraft:unbreaking":13}] if items entity @s container.* bow run function manarune:amulets/archer/lev_bow/levremove
