execute as @a[scores={level=8..}] if items entity @s weapon.offhand diamond[enchantments={"minecraft:unbreaking":11}] if items entity @s weapon.mainhand bow run enchant @s manarune:lightning_bow
execute as @a[scores={level=8..}] if items entity @s weapon.offhand diamond[enchantments={"minecraft:unbreaking":11}] if items entity @s weapon.mainhand bow run enchant @s manarune:lightning_bow
execute as @a unless items entity @s weapon.offhand diamond[enchantments={"minecraft:unbreaking":11}] if items entity @s container.* bow run function manarune:amulets/archer/lightning_bow/lightremove
