execute as @e[tag=!mana1,type=armadillo] run tag @s add mana1
execute as @e[tag=!mana1,type=axolotl] run tag @s add mana1
execute as @e[tag=!mana1,type=bat] run tag @s add mana1
execute as @e[tag=!mana1,type=bee] run tag @s add mana1
execute as @e[tag=!mana1,type=cat] run tag @s add mana1
execute as @e[tag=!mana1,type=chicken] run tag @s add mana1
execute as @e[tag=!mana1,type=cod] run tag @s add mana1
execute as @e[tag=!mana1,type=dolphin] run tag @s add mana1
execute as @e[tag=!mana1,type=ocelot] run tag @s add mana1
execute as @e[tag=!mana1,type=parrot] run tag @s add mana1
execute as @e[tag=!mana1,type=pufferfish] run tag @s add mana1
execute as @e[tag=!mana1,type=rabbit] run tag @s add mana1
execute as @e[tag=!mana1,type=salmon] run tag @s add mana1
execute as @e[tag=!mana1,type=silverfish] run tag @s add mana1
execute as @e[tag=!mana1,type=squid] run tag @s add mana1
execute as @e[tag=!mana1,type=tadpole] run tag @s add mana1
execute as @e[tag=!mana1,type=tropical_fish] run tag @s add mana1
execute as @e[tag=!mana1,type=tropical_fish] run tag @s add mana1
execute as @e[tag=!mana1,type=tropical_fish] run tag @s add mana1
execute as @e[tag=!mana1,type=tropical_fish] run tag @s add mana1
execute as @e[tag=!mana1,type=tropical_fish] run tag @s add mana1
execute as @e[tag=!mana1,type=tropical_fish] run tag @s add mana1
execute as @e[tag=!mana1,type=tropical_fish] run tag @s add mana1
execute as @e[tag=!mana1,type=tropical_fish] run tag @s add mana1

tag @e[tag=!mana2big,type=cow] add mana2big
tag @e[tag=!mana2big,type=donkey] add mana2big
tag @e[tag=!mana2big,type=glow_squid] add mana2big
tag @e[tag=!mana2big,type=goat] add mana2big
tag @e[tag=!mana2big,type=guardian] add mana2big
tag @e[tag=!mana2big,type=panda] add mana2big
tag @e[tag=!mana2big,type=horse] add mana2big
tag @e[tag=!mana2big,type=llama] add mana2big
tag @e[tag=!mana2big,type=mooshroom] add mana2big
tag @e[tag=!mana2big,type=mule] add mana2big
tag @e[tag=!mana2big,type=pig] add mana2big
tag @e[tag=!mana2big,type=polar_bear] add mana2big
tag @e[tag=!mana2big,type=sheep] add mana2big
tag @e[tag=!mana2big,type=slime] add mana2big
tag @e[tag=!mana2big,type=trader_llama] add mana2big
tag @e[tag=!mana2big,type=turtle] add mana2big
tag @e[tag=!mana2big,type=mule] add mana2big
tag @e[tag=!mana2big,type=mule] add mana2big
tag @e[tag=!mana2big,type=mule] add mana2big
tag @e[tag=!mana2big,type=mule] add mana2big

tag @e[tag=!mana2small,type=allay] add mana2small
tag @e[tag=!mana2small,type=cave_spider] add mana2small
tag @e[tag=!mana2small,type=copper_golem] add mana2small
tag @e[tag=!mana2small,type=endermite] add mana2small
tag @e[tag=!mana2small,type=fox] add mana2small
tag @e[tag=!mana2small,type=frog] add mana2small
tag @e[tag=!mana2small,type=phantom] add mana2small
tag @e[tag=!mana2small,type=vex] add mana2small
tag @e[tag=!mana2small,type=wolf] add mana2small
tag @e[tag=!mana2small,type=nautilus] add mana2small
tag @e[tag=!mana2small,type=zombie_nautilus] add mana2small
tag @e[tag=!mana2small,type=spider] add mana2small

tag @e[tag=!mana3,type=bogged] add mana3
tag @e[tag=!mana3,type=creeper] add mana3
tag @e[tag=!mana3,type=drowned] add mana3
tag @e[tag=!mana3,type=evoker] add mana3
tag @e[tag=!mana3,type=husk] add mana3
tag @e[tag=!mana3,type=drowned] add mana3
tag @e[tag=!mana3,type=skeleton] add mana3
tag @e[tag=!mana3,type=skeleton_horse] add mana3
tag @e[tag=!mana3,type=snow_golem] add mana3
tag @e[tag=!mana3,type=stray] add mana3
tag @e[tag=!mana3,type=villager] add mana3
tag @e[tag=!mana3,type=wandering_trader] add mana3
tag @e[tag=!mana3,type=witch] add mana3
tag @e[tag=!mana3,type=zombie] add mana3
tag @e[tag=!mana3,type=minecraft:zombie_villager] add mana3
tag @e[tag=!mana3,type=minecraft:zombie_horse] add mana3


tag @e[tag=!mana4,type=breeze] add mana4
tag @e[tag=!mana4,type=creaking] add mana4
tag @e[tag=!mana4,type=enderman] add mana4
tag @e[tag=!mana4,type=vindicator] add mana4
tag @a[tag=!classed] add mana4

tag @a[tag=warrior] add mana5
tag @a[tag=archer] add mana5

tag @a[tag=cleric] add mana6
tag @a[tag=wizard] add mana6
tag @a[tag=acolyte] add mana6

tag @e[tag=!mana7,tag=magichalf] add mana7

tag @e[tag=!mana8,tag=magicfull] add mana8

tag @e[tag=!manabig,type=camel] add manabig
tag @e[tag=!manabig,type=elder_guardian] add manabig
tag @e[tag=!manabig,type=happy_ghast] add manabig
tag @e[tag=!manabig,type=iron_golem] add manabig
tag @e[tag=!manabig,type=happy_ghast] add manabig
tag @e[tag=!manabig,type=ravager] add manabig
tag @e[tag=!manabig,type=sniffer] add manabig
tag @e[tag=!manabig,type=happy_ghast] add manabig
tag @e[tag=!manabig,type=warden] add manabig
tag @e[tag=!manabig,type=wither] add manabig