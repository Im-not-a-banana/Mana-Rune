advancement revoke @s only manarune:manarune/nondisplayadvancements/manaflowhit
execute as @s[nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:mending":10}}}},tag=manaflow] at @s run tag @e[nbt={HurtTime:10s},distance=..5,limit=10,sort=nearest] add manadry
