execute if entity @a[tag=manaflow] at @e[tag=mana2big,tag=!manadry] run particle minecraft:dust{color:[0.21,0.69,0.79],scale:1} ~ ~1 ~ 0.3 0.3 0.3 0 3 normal @a[tag=manaflow,nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:mending":10}}}}]
execute if entity @a[tag=manaflow] at @e[tag=mana2big,tag=manadry] run particle minecraft:dust{color:[0.5,0.5,0.5],scale:1} ~ ~1 ~ 0.2 0.2 0.2 0 1 normal @a[tag=manaflow,nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:mending":10}}}}]
execute at @a[tag=manaflow] run damage @e[tag=manadry,tag=mana2big,sort=nearest,limit=1] 3 magic

execute if entity @a[tag=manaflow] run schedule function manarune:amulets/manaflow/particles/mana2big 8t append
