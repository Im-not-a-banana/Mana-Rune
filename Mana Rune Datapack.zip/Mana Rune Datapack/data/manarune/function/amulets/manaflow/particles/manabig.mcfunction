execute if entity @a[tag=manaflow] at @e[tag=manabig,tag=!manadry] run particle minecraft:dust{color:[0.21,0.69,0.79],scale:1} ~ ~1.5 ~ 0.7 0.9 0.7 0 2 normal @a[tag=manaflow,tag=manaflow,nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:mending":10}}}}]
execute if entity @a[tag=manaflow] at @e[tag=manabig,tag=manadry] run particle minecraft:dust{color:[0.5,0.5,0.5],scale:1} ~ ~1.5 ~ 0.7 0.9 0.7 0 2 normal @a[tag=manaflow,tag=manaflow,nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:mending":10}}}}]
execute at @a[tag=manaflow] run damage @e[tag=manadry,tag=manabig,sort=nearest,limit=1] 4 magic

execute if entity @a[tag=manaflow] run schedule function manarune:amulets/manaflow/particles/manabig 1t append
