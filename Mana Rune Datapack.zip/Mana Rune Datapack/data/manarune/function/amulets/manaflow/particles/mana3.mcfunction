execute if entity @a[tag=manaflow] at @e[tag=mana3,tag=!manadry] run particle minecraft:dust{color:[0.21,0.69,0.79],scale:1} ~ ~1 ~ 0.5 0.6 0.5 0 2 normal @a[tag=manaflow,nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:mending":10}}}}]
execute if entity @a[tag=manaflow] at @e[tag=mana3,tag=manadry] run particle minecraft:dust{color:[0.5,0.5,0.5],scale:1} ~ ~1 ~ 0.2 0.2 0.2 0 1 normal @a[tag=manaflow,nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:mending":10}}}}]
execute at @a[tag=manaflow] run damage @e[tag=manadry,tag=mana3,sort=nearest,limit=1] 3 magic

execute if entity @a[tag=manaflow] run schedule function manarune:amulets/manaflow/particles/mana3 4t append
