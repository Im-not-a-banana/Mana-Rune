execute as @a[scores={UsedWand=1..,level=15..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:mending":10}}}},tag=acolyte] at @s run tag @s add manaflow
execute as @a[scores={UsedWand=1..,level=15..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:mending":10}}}},tag=acolyte] at @s run tag @s add manaflowgo
execute at @a[tag=manaflow] run function manarune:amulets/manaflow/entitymanacheck
execute as @a[scores={UsedWand=1..},nbt={SelectedItem:{id:"minecraft:fishing_rod",components:{"minecraft:enchantments":{"minecraft:mending":10}}}}] at @s run kill @e[type=fishing_bobber,distance=..5]

execute as @a[tag=manaflowgo] run function manarune:amulets/manaflow/entitymanacheck
execute as @a[tag=manaflowgo] run function manarune:amulets/manaflow/particles/particlestart

execute as @a[tag=manaflowgo] run schedule function manarune:amulets/manaflow/manaflowremove 10s append
tag @a[tag=manaflowgo] remove manaflowgo

execute as @a[scores={UsedWand=1..,level=15..},tag=manaflow] run scoreboard players set @s UsedWand 0
