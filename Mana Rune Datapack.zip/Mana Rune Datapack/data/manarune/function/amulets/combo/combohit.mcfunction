advancement revoke @s only manarune:manarune/nondisplayadvancements/combohit
execute as @s[scores={level=9..},tag=!acolyte] if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run scoreboard players set @s Combo 20
execute as @s[scores={level=9..},tag=acolyte] if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run scoreboard players set @s Combo 15
execute as @s[scores={level=9..}] if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run scoreboard players add @s Combochain 1

execute as @s[scores={level=9..,Combochain=1..2}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run damage @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] 0 player_attack by @s
execute as @s[scores={level=9..,Combochain=3..4}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run damage @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] 1 player_attack by @s
execute as @s[scores={level=9..,Combochain=5..6}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run damage @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] 2 player_attack by @s
execute as @s[scores={level=9..,Combochain=7..8}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run damage @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] 3 player_attack by @s
execute as @s[scores={level=9..,Combochain=9..10}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run damage @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] 4 player_attack by @s
execute as @s[scores={level=9..,Combochain=11..12}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run damage @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] 5 player_attack by @s
execute as @s[scores={level=9..,Combochain=13..14}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run damage @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] 6 player_attack by @s
execute as @s[scores={level=9..,Combochain=15..17}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run damage @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] 7 player_attack by @s
execute as @s[scores={level=9..,Combochain=18..}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run damage @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] 8 player_attack by @s

execute as @s[scores={level=9..,Combochain=3..8}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] at @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] run particle minecraft:crit ~ ~2 ~ 0.2 0.2 0.2 1 10
execute as @s[scores={level=9..,Combochain=9..12}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] at @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] run particle minecraft:crit ~ ~2 ~ 0.2 0.2 0.2 1 15
execute as @s[scores={level=9..,Combochain=13..17}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] at @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] run particle minecraft:enchanted_hit ~ ~2 ~ 0.2 0.2 0.2 1 20
execute as @s[scores={level=9..,Combochain=18..}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] at @e[nbt={HurtTime:10s},distance=..5,limit=1,sort=nearest] run particle minecraft:enchanted_hit ~ ~2 ~ 0.2 0.2 0.2 1 25

execute as @s[scores={level=9..,Combochain=3..8}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run playsound minecraft:entity.player.attack.knockback master @a ~ ~1.5 ~ 1 1 0
execute as @s[scores={level=9..,Combochain=9..12}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run playsound minecraft:entity.player.attack.knockback master @a ~ ~1.5 ~ 2 1 0
execute as @s[scores={level=9..,Combochain=13..17}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run playsound minecraft:entity.player.attack.knockback master @a ~ ~1.5 ~ 3 1 0
execute as @s[scores={level=9..,Combochain=18..}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":2}] run playsound minecraft:entity.player.attack.knockback master @a ~ ~1.5 ~ 4 1 0
