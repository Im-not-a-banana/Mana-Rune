execute as @a[scores={level=12..},tag=acolyte] if items entity @s weapon.offhand diamond[enchantments={"minecraft:lure":6}] run attribute @s attack_damage modifier add minecraft:dadd 9.0 add_value
execute as @a unless items entity @s weapon.offhand diamond[enchantments={"minecraft:lure":6}] run attribute @s attack_damage modifier remove minecraft:dadd
execute as @a[scores={level=13..},tag=warrior] if items entity @s weapon.offhand diamond[enchantments={"minecraft:lure":6}] run attribute @s attack_damage modifier add minecraft:dadd 9.0 add_value
execute as @a unless items entity @s weapon.offhand diamond[enchantments={"minecraft:lure":6}] run attribute @s attack_damage modifier remove minecraft:dadd
execute as @a[scores={level=12..},tag=acolyte] if items entity @s weapon.offhand diamond[enchantments={"minecraft:lure":6}] run attribute @s max_health modifier add minecraft:hadda -6.0 add_value
execute as @a unless items entity @s weapon.offhand diamond[enchantments={"minecraft:lure":6}] run attribute @s max_health modifier remove minecraft:hadda
execute as @a[scores={level=13..},tag=warrior] if items entity @s weapon.offhand diamond[enchantments={"minecraft:lure":6}] run attribute @s max_health modifier add minecraft:haddw -8.0 add_value
execute as @a unless items entity @s weapon.offhand diamond[enchantments={"minecraft:lure":6}] run attribute @s max_health modifier remove minecraft:haddw
