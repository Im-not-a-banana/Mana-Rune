execute as @a[scores={level=12..},tag=!wizard,tag=!cleric] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:mending":2}] run tag @s add mana
execute as @a[scores={level=12..},tag=cleric] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:mending":2}] run tag @s remove mana
execute as @a[scores={level=12..},tag=wizard] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:mending":2}] run tag @s remove mana
execute as @a at @s unless items entity @s weapon.offhand diamond[enchantments={"minecraft:mending":2}] run tag @s remove mana
