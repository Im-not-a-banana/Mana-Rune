xp add @s 150 points
scoreboard players add @s completion 4
