xp add @s 100 points
scoreboard players add @s completion 3
