xp add @s 50 points
scoreboard players add @s completion 1
