xp add @s 40 points
scoreboard players add @s completion 1
