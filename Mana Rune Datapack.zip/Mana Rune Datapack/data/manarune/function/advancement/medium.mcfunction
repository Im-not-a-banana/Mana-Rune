xp add @s 85 points
scoreboard players add @s completion 2
