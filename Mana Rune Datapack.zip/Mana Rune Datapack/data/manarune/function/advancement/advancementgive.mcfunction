advancement grant @a[tag=wandcrafter] only manarune:manarune/crafting/wandcrafter
advancement grant @a[tag=amuletcrafter] only manarune:manarune/crafting/amuletcrafter
advancement grant @a[tag=wamuletcrafter] only manarune:manarune/crafting/amuletcrafter
advancement grant @a[tag=aamuletcrafter] only manarune:manarune/crafting/amuletcrafter
advancement grant @a[tag=classed] only manarune:manarune/general/classed

execute as @a[scores={maxhp=22..}] run advancement grant @s only manarune:manarune/general/ascendedheart1
execute as @a[scores={maxhp=40}] run advancement grant @s only manarune:manarune/general/ascendedheart10
execute as @a[scores={level=1..}] run advancement grant @s only manarune:manarune/general/sit1
execute as @a[scores={level=14..}] run advancement grant @s only manarune:manarune/general/sit10
execute as @a[scores={level=20}] run advancement grant @s only manarune:manarune/master

#true master
execute as @a[scores={completion=100}] run advancement grant @s only manarune:manarune/truemaster

#sit
execute at @e[type=pig,tag=seat] as @a[limit=1,sort=nearest] at @s if block ~ ~0.5 ~ campfire run advancement grant @s only manarune:manarune/general/campfiresit
execute at @e[type=pig,tag=seat] as @a[limit=1,sort=nearest] at @s if block ~ ~ ~ gold_block run advancement grant @s only manarune:manarune/general/thronesit

#classcraft
execute as @a[advancements={manarune:manarune/crafting/smithing/blacksmith=true}] run advancement grant @s only manarune:manarune/crafting/classcraft
execute as @a[advancements={manarune:manarune/crafting/fletching/fletcher=true}] run advancement grant @s only manarune:manarune/crafting/classcraft
execute as @a[advancements={manarune:manarune/crafting/brewing/brewer=true}] run advancement grant @s only manarune:manarune/crafting/classcraft

#smithing
execute as @a if items entity @s container.* *[custom_data={longsword:1b}] run advancement grant @s only manarune:manarune/crafting/smithing/longsword
execute as @a if items entity @s container.* *[custom_data={iron_longsword:1b}] run advancement grant @s only manarune:manarune/crafting/smithing/longsword
execute as @a if items entity @s container.* *[custom_data={diamond_longsword:1b}] run advancement grant @s only manarune:manarune/crafting/smithing/longsword
execute as @a if items entity @s container.* *[custom_data={greatsword1:1b}] run advancement grant @s only manarune:manarune/crafting/smithing/greatsword1
execute as @a if items entity @s container.* *[custom_data={greatsword2:1b}] run advancement grant @s only manarune:manarune/crafting/smithing/greatsword2
execute as @a[tag=wamuletcrafter] run advancement grant @s only manarune:manarune/crafting/smithing/wamuletcrafter
execute as @a[advancements={manarune:manarune/crafting/smithing/longsword=true}] run advancement grant @s only manarune:manarune/crafting/smithing/blacksmith
execute as @a[advancements={manarune:manarune/crafting/smithing/greatsword1=true}] run advancement grant @s only manarune:manarune/crafting/smithing/blacksmith
execute as @a[advancements={manarune:manarune/crafting/smithing/wamuletcrafter=true}] run advancement grant @s only manarune:manarune/crafting/smithing/blacksmith

#brewing
execute as @a if items entity @s container.* *[custom_data={custpot:1b}] run advancement grant @s only manarune:manarune/crafting/brewing/custpot
execute as @a if items entity @s container.* *[custom_data={healwand:1b}] run advancement grant @s only manarune:manarune/crafting/brewing/healwand
execute as @a[advancements={manarune:manarune/crafting/brewing/custpot=true}] run advancement grant @s only manarune:manarune/crafting/brewing/brewer
execute as @a[advancements={manarune:manarune/crafting/brewing/healwand=true}] run advancement grant @s only manarune:manarune/crafting/brewing/brewer

#fletching
execute as @a[tag=aamuletcrafter] run advancement grant @s only manarune:manarune/crafting/fletching/archam
execute as @a if items entity @s container.* *[custom_data={tipped_arrow:1b}] run advancement grant @s only manarune:manarune/crafting/fletching/tippedarrow
execute as @a if items entity @s container.* *[custom_data={greatbow1:1b}] run advancement grant @s only manarune:manarune/crafting/fletching/greatbow1
execute as @a if items entity @s container.* *[custom_data={greatbow2:1b}] run advancement grant @s only manarune:manarune/crafting/fletching/greatbow2
execute as @a[advancements={manarune:manarune/crafting/fletching/archam=true}] run advancement grant @s only manarune:manarune/crafting/fletching/fletcher
execute as @a[advancements={manarune:manarune/crafting/fletching/tippedarrow=true}] run advancement grant @s only manarune:manarune/crafting/fletching/fletcher
execute as @a[advancements={manarune:manarune/crafting/fletching/greatbow1=true}] run advancement grant @s only manarune:manarune/crafting/fletching/fletcher