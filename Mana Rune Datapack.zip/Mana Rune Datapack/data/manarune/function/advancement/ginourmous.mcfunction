xp add @s 500 points
scoreboard players add @s completion 5
