$tellraw @s '[Info] §7You have attained $(player)% completion.'
