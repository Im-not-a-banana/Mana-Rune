effect give @e[limit=1,sort=nearest] poison 20 2
