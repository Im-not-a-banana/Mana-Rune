summon tnt ~ ~ ~ {fuse:0,Tags:["exploderbow"]}
execute at @e[type=tnt,tag=exploderbow] as @e[type=arrow,distance=..0.1] run kill @s
