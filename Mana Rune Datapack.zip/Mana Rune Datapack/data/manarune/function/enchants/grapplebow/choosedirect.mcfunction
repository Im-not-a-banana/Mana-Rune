execute at @s[tag=archer] anchored eyes positioned -0.00000000001 0 -0.00000000001 run summon marker ^ ^ ^-1.2 {Tags:["gpd"]}
execute as @e[type=marker,tag=gpd] positioned -0.00000000001 0 -0.00000000001 at @s run tp @s[y=0.4,dy=-5,x=5,dx=-10,z=5,dz=-10] ~ 0.4 ~
