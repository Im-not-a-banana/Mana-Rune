data modify entity @s Motion set from entity @e[type=marker,tag=gpd,limit=1] Pos
kill @e[tag=gpd]
