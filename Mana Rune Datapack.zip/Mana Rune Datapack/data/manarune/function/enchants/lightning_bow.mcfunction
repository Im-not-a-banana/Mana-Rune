summon lightning_bolt ~ ~ ~ {fuse:0,Tags:["lightningbow"]}
particle ash ~ ~ ~ 1 1 1 10 50
particle white_ash ~ ~ ~ 1 1 1 10 50
particle minecraft:crit ~ ~ ~ 0 0 0 1 50
particle electric_spark ~ ~ ~ 1 1 1 0 80
particle block{block_state:{Name:light,Properties:{level:"15"}}} ~ ~ ~ 0 0 0 1 100
execute unless block ~ ~ ~ bedrock run setblock ~ ~ ~ fire
execute at @e[type=lightning_bolt,tag=lightningbow] as @e[type=arrow,distance=..0.1] run kill @s
