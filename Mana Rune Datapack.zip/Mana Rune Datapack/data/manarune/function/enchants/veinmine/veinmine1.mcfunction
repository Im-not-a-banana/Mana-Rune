execute as @s[scores={VeinMine=..0},tag=veinminer] run tag @s remove veinminer
execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~ ~ ~-1 all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 positioned ~ ~ ~-1 unless entity @e[type=interaction,tag=prechopped,distance=0] run summon interaction ~ ~ ~ {Tags:["prechopped"]}
execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~ ~ ~1 all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 positioned ~ ~ ~1 unless entity @e[type=interaction,tag=prechopped,distance=0] run summon interaction ~ ~ ~ {Tags:["prechopped"]}
execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~ ~-1 ~ all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 positioned ~ ~-1 ~ unless entity @e[type=interaction,tag=prechopped,distance=0] run summon interaction ~ ~ ~ {Tags:["prechopped"]}
execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~ ~1 ~ all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 positioned ~ ~1 ~ unless entity @e[type=interaction,tag=prechopped,distance=0] run summon interaction ~ ~ ~ {Tags:["prechopped"]}
execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~-1 ~ ~ all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 positioned ~-1 ~ ~ unless entity @e[type=interaction,tag=prechopped,distance=0] run summon interaction ~ ~ ~ {Tags:["prechopped"]}
execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~1 ~ ~ all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 positioned ~1 ~ ~ unless entity @e[type=interaction,tag=prechopped,distance=0] run summon interaction ~ ~ ~ {Tags:["prechopped"]}




execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~ ~ ~-1 all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 unless entity @e[type=interaction,tag=prechopped,distance=0] run scoreboard players operation @a[tag=veinminer] VeinMine -= veindecrease VeinMine
execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~ ~ ~1 all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 unless entity @e[type=interaction,tag=prechopped,distance=0] run scoreboard players operation @a[tag=veinminer] VeinMine -= veindecrease VeinMine
execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~ ~-1 ~ all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 unless entity @e[type=interaction,tag=prechopped,distance=0] run scoreboard players operation @a[tag=veinminer] VeinMine -= veindecrease VeinMine
execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~ ~1 ~ all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 unless entity @e[type=interaction,tag=prechopped,distance=0] run scoreboard players operation @a[tag=veinminer] VeinMine -= veindecrease VeinMine
execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~-1 ~ ~ all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 unless entity @e[type=interaction,tag=prechopped,distance=0] run scoreboard players operation @a[tag=veinminer] VeinMine -= veindecrease VeinMine
execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s if blocks ~ ~ ~ ~ ~ ~ ~1 ~ ~ all unless block ~ ~ ~ air unless score @s VeinMine matches ..0 unless entity @e[type=interaction,tag=prechopped,distance=0] run scoreboard players operation @a[tag=veinminer] VeinMine -= veindecrease VeinMine



execute if entity @s[tag=veinminer] as @e[type=interaction,tag=chopped] at @s run setblock ~ ~ ~ air destroy
kill @e[tag=chopped]
function manarune:enchants/veinmine/veinmine2

