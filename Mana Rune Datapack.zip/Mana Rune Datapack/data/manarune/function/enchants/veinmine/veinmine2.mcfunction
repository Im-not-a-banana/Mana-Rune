execute as @s[scores={VeinMine=..0},tag=veinminer] run tag @s remove veinminer
execute if entity @s[tag=veinminer] at @e[type=interaction,tag=prechopped] run summon interaction ~ ~ ~ {Tags:["chopped"]}
kill @e[tag=prechopped]
execute if entity @s[tag=veinminer] at @e[type=interaction,tag=chopped] run function manarune:enchants/veinmine/veinmine1
