tag @s add veinminer
execute as @s[scores={sneaktrack=1..}] unless block ~ ~ ~ bedrock if items entity @s weapon.mainhand *[enchantments={"manarune:veinminer":1}] run scoreboard players set @s VeinMine 32
execute as @s[scores={sneaktrack=1..}] unless block ~ ~ ~ bedrock if items entity @s weapon.mainhand *[enchantments={"manarune:veinminer":2}] run scoreboard players set @s VeinMine 64
execute as @s[scores={sneaktrack=1..}] unless block ~ ~ ~ bedrock if items entity @s weapon.mainhand *[enchantments={"manarune:veinminer":3}] run scoreboard players set @s VeinMine 96
execute as @s[scores={sneaktrack=1..}] unless block ~ ~ ~ bedrock run summon minecraft:interaction ~ ~ ~ {Tags:["chopped"]}
execute as @s[scores={sneaktrack=1..}] unless block ~ ~ ~ bedrock positioned ~ ~ ~ run function manarune:enchants/veinmine/veinmine1
