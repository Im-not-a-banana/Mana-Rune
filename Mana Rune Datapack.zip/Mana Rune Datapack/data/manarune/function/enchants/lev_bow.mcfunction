effect give @e[limit=1,sort=nearest] levitation 20 2
