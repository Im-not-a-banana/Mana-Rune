execute at @s[tag=acolyte] anchored eyes positioned -0.00000000001 0 -0.00000000001 run summon marker ^ ^ ^0.3 {Tags:["abd"]}
execute as @e[type=marker,tag=abd] positioned -0.00000000001 0 -0.00000000001 at @s run tp @s[y=0.5,dy=-5,x=5,dx=-10,z=5,dz=-10] ~ 0.5 ~
execute at @s[tag=acolyte] run tag @e[type=!player,limit=1,sort=nearest,nbt={HurtTime:10s},distance=..5] add abp
execute at @s[tag=acolyte] as @e[tag=abp] run data modify entity @s Motion set from entity @e[type=marker,tag=abd,limit=1] Pos
tag @e[tag=abp] remove abp
kill @e[tag=abd]
