execute at @e[type=interaction,tag=cg] as @e[distance=..5,type=!player,type=!interaction] run damage @s 2 magic
execute if entity @e[type=interaction,tag=cg] run schedule function manarune:enchants/greatsword/kb 3t append
