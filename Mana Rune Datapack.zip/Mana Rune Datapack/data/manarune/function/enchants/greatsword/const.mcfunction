execute as @e[type=interaction,tag=cg] at @s run tp @s ~ ~ ~ ~50 ~
execute as @e[type=interaction,tag=cg] at @s run particle dust{color:[0.68,0.49,0.87],scale:3} ^ ^1 ^5 0 0 0 0 10
execute as @e[type=interaction,tag=cgg] at @s run tp @s ~ ~ ~ ~50 ~
execute as @e[type=interaction,tag=cgg] at @s run particle dust{color:[0.71,0.23,0.23],scale:3} ^ ^1 ^5 0 0 0 0 10

execute if entity @e[type=interaction,tag=cg] run schedule function manarune:enchants/greatsword/const 1t append
execute if entity @e[type=interaction,tag=cgg] run schedule function manarune:enchants/greatsword/const 1t append
