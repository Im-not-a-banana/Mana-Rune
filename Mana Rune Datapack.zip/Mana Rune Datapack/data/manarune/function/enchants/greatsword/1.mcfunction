execute if entity @s[tag=warrior,scores={level=14..}] if items entity @s weapon.mainhand diamond_sword[custom_name=[{"text":"Diamond Greatsword","italic":false,"color":"aqua"}]] store result score @s greatsword run random value 1..10
execute if score @s greatsword matches 10 run tag @s add gattack

scoreboard players set @s greatsword -1
execute if entity @s[tag=warrior,scores={level=14..}] if items entity @s weapon.mainhand netherite_sword[custom_name=[{"text":"Godsoul Greatsword","italic":false,"color":"dark_green"}]] store result score @s greatsword run random value 1..7
execute if score @s greatsword matches 7 run tag @s add ggattack

execute at @s[tag=gattack] run summon interaction ~ ~ ~ {width:0,height:0,Tags:["cg"]}
execute at @s[tag=ggattack] run summon interaction ~ ~ ~ {width:0,height:0,Tags:["cgg"]}
execute if entity @s[tag=warrior,scores={level=14..}] run schedule function manarune:enchants/greatsword/end 5s
execute if entity @s[tag=warrior,scores={level=14..}] run function manarune:enchants/greatsword/const
execute as @s[tag=ggattack] run function manarune:enchants/greatsword/kb2
execute as @s[tag=gattack] run function manarune:enchants/greatsword/kb

scoreboard players set @s greatsword -1
