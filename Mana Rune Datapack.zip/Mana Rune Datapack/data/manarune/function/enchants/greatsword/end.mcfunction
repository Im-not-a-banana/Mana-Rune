kill @e[type=interaction,tag=cg]
kill @e[type=interaction,tag=cgg]
tag @a[tag=gattack] remove gattack
tag @a[tag=ggattack] remove ggattack
