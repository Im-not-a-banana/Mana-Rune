execute at @e[type=interaction,tag=cgg] as @e[distance=..5,type=!player,type=!interaction] run damage @s 3 magic
execute if entity @e[type=interaction,tag=cgg] run schedule function manarune:enchants/greatsword/kb2 2t append
