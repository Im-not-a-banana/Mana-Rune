#functions
function manarune:glowparty


#other random code
execute as @a[tag=wizard] run title @s actionbar ["§dClass: Wizard --- Level: ",{"score":{"name":"@s","objective":"level"},"color":"light_purple"}]
execute as @a[tag=warrior] run title @s actionbar ["§4Class: Warrior --- Level: ",{"score":{"name":"@s","objective":"level"},"color":"dark_red"}]
execute as @a[tag=acolyte] run title @s actionbar ["§6Class: Acolyte --- Level: ",{"score":{"name":"@s","objective":"level"},"color":"gold"}]
execute as @a[tag=cleric] run title @s actionbar ["§5Class: Cleric --- Level: ",{"score":{"name":"@s","objective":"level"},"color":"dark_purple"}]
execute as @a[tag=archer] run title @s actionbar ["§3Class: Archer --- Level: ",{"score":{"name":"@s","objective":"level"},"color":"dark_aqua"}]
execute as @a[tag=!classed] run title @s actionbar ["Unclassed --- Level: ",{"score":{"name":"@s","objective":"level"}}]
execute as @a[scores={sneaktrack=150..,level=1..}] run title @s actionbar 'Release shift to sit down.'


schedule function manarune:loops/10t 10t append
