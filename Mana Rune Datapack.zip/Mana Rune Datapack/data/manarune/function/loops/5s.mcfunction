#functions
function manarune:advancement/advancementgive


#other random code
execute as @a[tag=warrior] run attribute @s attack_damage base set 2
execute as @a[tag=!warrior] run attribute @s attack_damage base set 1

execute as @a[tag=acolyte] run attribute @s attack_speed base set 4.5
execute as @a[tag=acolyte] run attribute @s movement_speed base set 0.15
execute as @a[tag=!acolyte] run attribute @s attack_speed base set 4
execute as @a[tag=!acolyte] run attribute @s movement_speed base set 0.1


schedule function manarune:loops/5s 5s append