#functions
function manarune:levelget
function manarune:infosystem
function manarune:recipe

#other random code
execute as @a[tag=warrior] run attribute @s attack_damage base set 2
execute as @a[tag=!warrior] run attribute @s attack_damage base set 1

execute as @a[tag=acolyte] run attribute @s attack_speed base set 4.5
execute as @a[tag=acolyte] run attribute @s movement_speed base set 0.15
execute as @a[tag=!acolyte] run attribute @s attack_speed base set 4
execute as @a[tag=!acolyte] run attribute @s movement_speed base set 0.1

execute as @a[scores={UsedWand=1..},tag=!earthwand,tag=!enderwand,tag=!fireball,tag=!icewand,tag=!lightning,tag=!manaflow,tag=!runlevslow,tag=!wfireball,tag=!wicewand,tag=!wlightning,tag=!sonicboomer,tag=!protected,tag=!planewand] run scoreboard players set @s UsedWand 0
execute as @e[type=wind_charge] at @s unless entity @a[distance=..500] run kill @s
execute as @e[type=#arrows] at @s unless entity @a[distance=..500] run kill @s


schedule function manarune:loops/10s 10s append