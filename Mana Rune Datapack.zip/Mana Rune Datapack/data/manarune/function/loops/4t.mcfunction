#functions
function manarune:wandstuff/inventorywandreplace
function manarune:classselect/switchmech
function manarune:floorcrafting/fletching_table
function manarune:floorcrafting/smithing_table
function manarune:floorcrafting/brewing_stand


#other random code
execute as @e[type=pig,tag=seat] at @s on passengers if entity @s[type=player] if block ~ ~ ~ air run function manarune:sitting/sitend
execute as @e[type=pig,tag=seat] at @s on passengers if entity @s[type=player] if block ~ ~ ~ water run function manarune:sitting/sitend
execute as @e[type=pig,tag=seat] at @s on passengers if entity @s[type=player] if block ~ ~ ~ lava run function manarune:sitting/sitend
execute as @e[type=pig,tag=seat] at @s on passengers if entity @s[type=player] if block ~ ~ ~ powder_snow run function manarune:sitting/sitend
execute as @e[type=pig,tag=seat] at @s on passengers if entity @s[type=player] if block ~ ~ ~ cobweb run function manarune:sitting/sitend
execute as @a[nbt={active_effects:[{id:"minecraft:regeneration",duration:-1}]}] at @s unless entity @e[type=pig,tag=seat,distance=..0.3] run effect clear @s regeneration

execute as @e[type=pig,tag=seat] at @s if block ~ ~ ~ air run tp @s ~ -100000 ~
execute as @e[type=pig,tag=seat] at @s if block ~ ~ ~ water run tp @s ~ -100000 ~
execute as @e[type=pig,tag=seat] at @s if block ~ ~ ~ lava run tp @s ~ -100000 ~
execute as @e[type=pig,tag=seat] at @s if block ~ ~ ~ powder_snow run tp @s ~ -100000 ~
execute as @e[type=pig,tag=seat] at @s if block ~ ~ ~ cobweb run tp @s ~ -100000 ~
execute as @e[type=pig,tag=seat] at @s unless entity @a[distance=..0.3] run tp @s ~ -100000 ~

execute if score maxvein VeinMine matches ..0 run kill @e[type=minecraft:marker,tag=chopped]
execute if score maxvein VeinMine matches ..0 run kill @e[type=minecraft:marker,tag=prechopped]
execute if score maxvein VeinMine matches ..0 run scoreboard players set maxvein VeinMine 64


schedule function manarune:loops/4t 4t append