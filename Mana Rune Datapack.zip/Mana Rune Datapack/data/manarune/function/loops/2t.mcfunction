#functions
function manarune:wandstuff/wandamuletfunctions


#other random code
execute as @a[scores={deathtrigger=1..},tag=manadry] run tag @s remove manadry
execute as @a[scores={deathtrigger=1..}] run scoreboard players set @s deathtrigger 0

execute as @a[tag=warrior,scores={damagetrack=1000..,level=14..}] at @s if items entity @s weapon.offhand diamond[enchantments={"minecraft:sharpness":8}] run particle block{block_state:{Name:redstone_block}} ~ ~1 ~ 0.7 0.7 0.7 0 2 normal

execute at @e[type=pig,tag=seat] as @a[distance=..2] run team join nocolentities @s
execute as @a at @s unless entity @e[type=pig,tag=seat,distance=..2] run team leave @s


schedule function manarune:loops/2t 2t append