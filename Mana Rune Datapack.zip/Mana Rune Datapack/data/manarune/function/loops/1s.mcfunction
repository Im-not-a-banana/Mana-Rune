#functions


#other random code
execute as @a at @a run fill ~-5 ~-5 ~-5 ~5 ~5 ~5 air replace nether_portal
scoreboard players enable @a infoselect

execute as @a[tag=wizard,scores={level=10..}] if items entity @s weapon.offhand diamond[enchantments={unbreaking:50}] run tag @s add mageaura
execute as @a[tag=mageaura] unless items entity @s weapon.offhand diamond[enchantments={unbreaking:50}] run tag @s remove mageaura

schedule function manarune:loops/1s 1s append
