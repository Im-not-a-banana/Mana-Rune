execute as @a[tag=reach] run attribute @s block_interaction_range modifier remove plusone
execute as @a[tag=reach] run attribute @s entity_interaction_range modifier remove plusone
execute as @a[tag=reach] run playsound block.beacon.power_select master @s ~ ~ ~ 1 1 1
tag @a[tag=reach] remove reach