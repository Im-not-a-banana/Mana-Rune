tag @s add reach
playsound block.beacon.activate master @s ~ ~ ~ 1 1 1
attribute @s block_interaction_range modifier add plusone 1 add_value
attribute @s entity_interaction_range modifier add plusone 1 add_value
