tellraw @a '[Info] §7Welcome to Mana Rune. If you forget something or need help, press G to look at all §r[Info] §7messages or other useful things.'

scoreboard objectives add UsedWand minecraft.used:minecraft.fishing_rod
scoreboard objectives add maxhp dummy
scoreboard objectives add deathtrigger deathCount
scoreboard objectives add raycast dummy
scoreboard objectives add sonicraycast dummy
scoreboard objectives add level dummy
scoreboard objectives add ClassSelect dummy
scoreboard objectives add ClassConfirm dummy
scoreboard objectives add Combo dummy
scoreboard objectives add Combochain dummy
scoreboard objectives add VeinMine dummy
scoreboard objectives add levelinfo dummy
scoreboard objectives add infoselect trigger
scoreboard objectives add greatsword dummy
scoreboard objectives add completion dummy

scoreboard objectives add xpforlevel dummy
scoreboard objectives add currentXP xp
scoreboard objectives add prevXP dummy
scoreboard objectives add xpgain dummy

scoreboard objectives add godrage dummy
execute as @a unless score @s godrage matches -1000.. run scoreboard players set @s godrage 0
scoreboard objectives add damagetrack dummy
scoreboard objectives add currentdamage minecraft.custom:minecraft.damage_dealt
scoreboard objectives add prevdamage dummy
scoreboard objectives add damagegain dummy

scoreboard objectives add sneaktrack dummy
scoreboard objectives add currentsneak minecraft.custom:minecraft.sneak_time
scoreboard objectives add prevsneak dummy
scoreboard objectives add sneakgain dummy


execute as @a unless score @s UsedWand matches -1000.. run scoreboard players set @s UsedWand 0
execute as @a unless score @s deathtrigger matches -1000.. run scoreboard players set @s deathtrigger 0
execute as @a unless score @s level matches -1.. run scoreboard players set @s level 0
execute as @a unless score @s ClassSelect matches -1000.. run scoreboard players set @s ClassSelect 0
execute as @a unless score @s ClassConfirm matches -1000.. run scoreboard players set @s ClassConfirm 0
execute as @a unless score @s greatsword matches -1000.. run scoreboard players set @s greatsword -1
execute as @a unless score @s completion matches -1000.. run scoreboard players set @s completion 0

scoreboard players set distance raycast 0
scoreboard players set stepdecrease raycast 1
scoreboard players set blockpart raycast 0

scoreboard players set sonicdistance sonicraycast 0
scoreboard players set sonicstepdecrease sonicraycast 1
scoreboard players set sonicblockpart sonicraycast 0

execute as @a unless score @s VeinMine matches -1000.. run scoreboard players set @s VeinMine 0
scoreboard players set veindecrease VeinMine 1

execute as @a unless score @s Combochain matches -1000.. run scoreboard players set @s Combochain 0
execute as @a unless score @s Combo matches -1000.. run scoreboard players set @s Combo -1
scoreboard players set combostep Combo 1

execute as @a unless score @s levelinfo matches -1000.. run scoreboard players set @s levelinfo 0


team add nocolentities
team modify nocolentities collisionRule never
team modify nocolentities seeFriendlyInvisibles false

