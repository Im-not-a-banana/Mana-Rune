scoreboard objectives add enablecheck dummy
scoreboard players add enabled enablecheck 1
execute if score enabled enablecheck matches 1 run function manarune:realload

function manarune:loops/1s
function manarune:loops/5s
function manarune:loops/2t
function manarune:loops/4t
function manarune:loops/10t
function manarune:loops/10s
