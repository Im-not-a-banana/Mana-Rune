tag @s add reach
attribute @s block_interaction_range modifier add plusone 1 add_value
attribute @s entity_interaction_range modifier add plusone 1 add_value
