execute as @a[tag=reach] run attribute @s block_interaction_range modifier remove plusone
execute as @a[tag=reach] run attribute @s entity_interaction_range modifier remove plusone
tag @a[tag=reach] remove reach