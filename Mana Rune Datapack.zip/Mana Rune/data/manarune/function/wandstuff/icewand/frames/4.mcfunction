execute at @e[tag=icewandgo] run fill ^ ^3 ^ ^ ^3 ^ ice destroy
execute at @e[tag=icewandgo] run playsound minecraft:block.basalt.hit ui @a ~ ~ ~ 1 1 1
schedule function manarune:wandstuff/icewand/frames/5 2t append
