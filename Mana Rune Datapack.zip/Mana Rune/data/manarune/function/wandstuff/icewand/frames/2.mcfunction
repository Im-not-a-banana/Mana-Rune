execute at @e[tag=icewandgo] run fill ^ ^1 ^1 ^ ^1 ^-1 ice destroy
execute at @e[tag=icewandgo] run fill ^1 ^1 ^ ^-1 ^1 ^ ice destroy
execute at @e[tag=icewandgo] run playsound minecraft:block.basalt.hit ui @a ~ ~ ~ 1 1 1
schedule function manarune:wandstuff/icewand/frames/3 2t append
