advancement grant @a[tag=wandcrafter] only manarune:manaruneadvancement/wandcrafter
tag @a remove wandcrafter
