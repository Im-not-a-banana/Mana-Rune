execute as @a[scores={Combo=0..}] run scoreboard players operation @s Combo -= combostep Combo
execute as @a[scores={Combochain=1..,Combo=-1}] run scoreboard players set @s Combochain 0
execute as @a[scores={Combo=0}] at @s run playsound block.note_block.pling master @a ~ ~ ~ 5 0.7 1
execute as @a[scores={Combo=0}] at @s run playsound block.note_block.pling master @a ~ ~ ~ 5 0.4 1
