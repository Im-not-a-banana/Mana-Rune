execute as @s[nbt={Dimension:"minecraft:overworld"}] run tag @s add ether
execute as @s[nbt={Dimension:"manarune:inbetween"}] run tag @s add ether
execute as @s[nbt={Dimension:"manarune:etherealplane"}] run tag @s add over
execute as @s[tag=over] in minecraft:overworld run spreadplayers ~ ~ 0 1 false @s
execute as @s[tag=ether] in manarune:etherealplane run spreadplayers ~ ~ 0 1 false @s
tag @s[tag=over,nbt={Dimension:"minecraft:overworld"}] remove over
tag @s[tag=ether,nbt={Dimension:"manarune:etherealplane"}] remove ether
execute as @s[tag=over,nbt={Dimension:"manarune:etherealplane"}] in minecraft:overworld run tp @s ~ 63 ~
execute at @s[tag=over] run setblock ~ 62 ~ grass_block
execute as @s[tag=ether,nbt={Dimension:"minecraft:overworld"}] in manarune:etherealplane run tp @s ~ ~ ~
execute as @s[tag=ether,nbt={Dimension:"manarune:inbetween"}] in manarune:etherealplane run tp @s ~ ~ ~
execute at @s[tag=ether] run setblock ~ ~-1 ~ grass_block
effect clear @s levitation
effect give @s blindness 2 1 true

execute at @s run playsound minecraft:planeswitch master @s ~ ~ ~ 1 1 1
execute at @s run playsound minecraft:planeswitch master @s ~ ~ ~ 1 0.3 1
tag @s remove planeswitch
tag @s[tag=over] remove over
tag @s[tag=ether] remove ether

