execute as @a[scores={level=1..,levelinfo=0}] run scoreboard players set @s levelinfo 1
execute as @a[scores={level=1..,levelinfo=1}] run tellraw @s '[Info] §7At level 1, you unlock an ability. You can now §bsit §7by sneaking for long enough. §bSitting §7can help you relax on almost any terrain.'
execute as @a[scores={level=1..,levelinfo=1}] run scoreboard players set @s levelinfo 2

execute as @a[scores={level=2..,levelinfo=2}] run scoreboard players set @s levelinfo 3
execute as @a[scores={level=2..,levelinfo=3}] run tellraw @s '[Info] §7At level 2, §bsitting §7becomes more powerful. §bSitting §7can now help you gain health.'
execute as @a[scores={level=2..,levelinfo=3}] run scoreboard players set @s levelinfo 4

execute as @a[scores={level=3..,levelinfo=4}] run scoreboard players set @s levelinfo 5
execute as @a[scores={level=3..,levelinfo=5}] run scoreboard players set @s levelinfo 6

execute as @a[scores={level=4..,levelinfo=6}] run scoreboard players set @s levelinfo 7
execute as @a[scores={level=4..,levelinfo=7}] run tellraw @s '[Info] §7At level 4, you can now choose a class. If you have a class chosen, you will also have enough mana to travel between planes, if you can find a way to do so. You also unlock custom recipes.'
execute as @a[scores={level=4..,levelinfo=7}] run give @s diamond[enchantments={unbreaking:2}]
execute as @a[scores={level=4..,levelinfo=7}] run recipe give @s manarune:othercustom/class
execute as @a[scores={level=4..,levelinfo=7}] run recipe give @s manarune:othercustom/ascendedheart
execute as @a[scores={level=4..,levelinfo=7}] run recipe give @s manarune:noncustom/totemofundying
execute as @a[scores={level=4..,levelinfo=7}] run recipe give @s manarune:noncustom/elytra
execute as @a[scores={level=4..,levelinfo=7}] run recipe give @s manarune:othercustom/pigstep
execute as @a[scores={level=4..,levelinfo=7}] run recipe give @s manarune:noncustom/glowstone2
execute as @a[scores={level=4..,levelinfo=7}] run recipe give @s manarune:noncustom/glowstonedust
execute as @a[scores={level=4..,levelinfo=7}] run scoreboard players set @s levelinfo 8

execute as @a[scores={level=5..,levelinfo=8}] run scoreboard players set @s levelinfo 9
execute as @a[scores={level=5..,levelinfo=9}] run scoreboard players set @s levelinfo 10

execute as @a[scores={level=6..,levelinfo=10}] run scoreboard players set @s levelinfo 11
execute as @a[scores={level=6..,levelinfo=11}] run tellraw @s '[Info] §7At level 6, you unlock custom recipes.'
execute as @a[scores={level=6..,levelinfo=11}] run recipe give @s manarune:othercustom/armorsetandweapons/leggingsjumping
execute as @a[scores={level=6..,levelinfo=11}] run recipe give @s manarune:othercustom/armorsetandweapons/partyhelmet
execute as @a[scores={level=6..,levelinfo=11}] run recipe give @s manarune:othercustom/armorsetandweapons/resiliencechestplate
execute as @a[scores={level=6..,levelinfo=11}] run recipe give @s manarune:othercustom/armorsetandweapons/tools/fort5
execute as @a[scores={level=6..,levelinfo=11}] run recipe give @s manarune:othercustom/armorsetandweapons/tools/fort8
execute as @a[scores={level=6..,levelinfo=11}] run recipe give @s manarune:othercustom/armorsetandweapons/tools/veinmine/veinmine1
execute as @a[scores={level=6..,levelinfo=11}] run recipe give @s manarune:othercustom/armorsetandweapons/tools/veinmine/veinmine2
execute as @a[scores={level=6..,levelinfo=11}] run recipe give @s manarune:othercustom/armorsetandweapons/tools/veinmine/veinmine3
execute as @a[scores={level=6..,levelinfo=11}] run recipe give @s manarune:othercustom/armorsetandweapons/travelerboots
execute as @a[scores={level=6..,levelinfo=11}] run scoreboard players set @s levelinfo 12

execute as @a[scores={level=7..,levelinfo=12}] run scoreboard players set @s levelinfo 13
execute as @a[scores={level=7..,levelinfo=13}] run tellraw @s '[Info] §7At level 7, you unlock a custom recipe.'
execute as @a[scores={level=7..,levelinfo=13}] run recipe give @s manarune:othercustom/godsoul/other/netherite_ingot
execute as @a[scores={level=7..,levelinfo=13}] run scoreboard players set @s levelinfo 14

execute as @a[scores={level=8..,levelinfo=14}] run scoreboard players set @s levelinfo 15
execute as @a[scores={level=8..,levelinfo=15}] run tellraw @s "[Info] §7At level 8, §bsitting's §7healing effect becomes more powerful."
execute as @a[scores={level=8..,levelinfo=15}] run scoreboard players set @s levelinfo 16

execute as @a[scores={level=9..,levelinfo=16}] run scoreboard players set @s levelinfo 17
execute as @a[scores={level=9..,levelinfo=17}] run scoreboard players set @s levelinfo 18

execute as @a[scores={level=10..,levelinfo=18}] run scoreboard players set @s levelinfo 19
execute as @a[scores={level=10..,levelinfo=18}] run tellraw @s '[Info] §7At level 10, you unlock a custom recipe.'
execute as @a[scores={level=10..,levelinfo=18}] run recipe give @s manarune:noncustom/elytra
execute as @a[scores={level=10..,levelinfo=19}] run scoreboard players set @s levelinfo 20

execute as @a[scores={level=11..,levelinfo=20}] run scoreboard players set @s levelinfo 21
execute as @a[scores={level=11..,levelinfo=21}] run scoreboard players set @s levelinfo 22

execute as @a[scores={level=12..,levelinfo=22}] run scoreboard players set @s levelinfo 23
execute as @a[scores={level=12..,levelinfo=23}] run scoreboard players set @s levelinfo 24

execute as @a[scores={level=13..,levelinfo=24}] run scoreboard players set @s levelinfo 25
execute as @a[scores={level=13..,levelinfo=25}] run scoreboard players set @s levelinfo 26

execute as @a[scores={level=14..,levelinfo=26}] run scoreboard players set @s levelinfo 27
execute as @a[scores={level=14..,levelinfo=27}] run tellraw @s "[Info] §7At level 14, §bsitting's §7healing effect becomes even more powerful."
execute as @a[scores={level=14..,levelinfo=27}] run scoreboard players set @s levelinfo 28

execute as @a[scores={level=15..,levelinfo=28}] run scoreboard players set @s levelinfo 29
execute as @a[scores={level=15..,levelinfo=29}] run scoreboard players set @s levelinfo 30

execute as @a[scores={level=16..,levelinfo=30}] run scoreboard players set @s levelinfo 31
execute as @a[scores={level=16..,levelinfo=31}] run scoreboard players set @s levelinfo 32

execute as @a[scores={level=17..,levelinfo=32}] run scoreboard players set @s levelinfo 33
execute as @a[scores={level=17..,levelinfo=33}] run scoreboard players set @s levelinfo 34

execute as @a[scores={level=18..,levelinfo=34}] run scoreboard players set @s levelinfo 35
execute as @a[scores={level=18..,levelinfo=35}] run scoreboard players set @s levelinfo 36

execute as @a[scores={level=19..,levelinfo=36}] run scoreboard players set @s levelinfo 37
execute as @a[scores={level=19..,levelinfo=37}] run scoreboard players set @s levelinfo 38

execute as @a[scores={level=20,levelinfo=38}] run scoreboard players set @s levelinfo 39
execute as @a[scores={level=20,levelinfo=39}] run tellraw @s "[Info] §7You have reached level 20. You are the master of your class and have learned all of it's secrets and traits."
execute as @a[scores={level=20,levelinfo=39}] run scoreboard players set @s levelinfo 40

#Class info

execute as @a[tag=acolyte,tag=!acolyteinfo] run tellraw @s '[Info] §6 You have chosen to be an Acolyte. This class focusses on divine power, religion, and amulets to focus divine will.'
execute as @a[tag=acolyte,tag=!acolyteinfo] run tag @s add acolyteinfo

execute as @a[tag=archer,tag=!archerinfo] run tellraw @s "[Info] §3 You have chosen to be an Archer. This class focusses on powerfull bows and arrows to target far enemies.  You begin to inherit knowledge from your anscestors. Press 'G' to look at new information."
execute as @a[tag=archer,tag=!archerinfo] run tag @s add archerinfo

execute as @a[tag=cleric,tag=!clericinfo] run tellraw @s "[Info] §5 You have chosen to be a Cleric. This class focusses on healing and conplex potions, as well as the use of wands. You have focussed mana and a mastery of wands above all classes that don't have foccused mana. Press 'G' to look at new information."
execute as @a[tag=cleric,tag=!clericinfo] run tag @s add clericinfo

execute as @a[tag=warrior,tag=!warriorinfo] run tellraw @s "[Info] §4 You have chosen to be a Warrior. This class focusses on pure mele combat and phisical prowess. You begin to inherit knowledge from your anscestors. Press 'G' to look at new information."
execute as @a[tag=warrior,tag=!warriorinfo] run tag @s add warriorinfo

execute as @a[tag=wizard,tag=!wizardinfo] run tellraw @s "[Info] §d You have chosen to be a Wizard. This class focusses on arcane power, mastery of mana, and the use of wands. Infact, with your mastery of mana, you can use wands better than any class that doesn't have focussed mana."
execute as @a[tag=wizard,tag=!wizardinfo] run tag @s add wizardinfo
