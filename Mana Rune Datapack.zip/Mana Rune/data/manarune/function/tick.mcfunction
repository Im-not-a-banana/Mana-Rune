execute as @a at @a run fill ~-5 ~-5 ~-5 ~5 ~5 ~5 air replace end_portal
execute as @e[type=ender_pearl] at @s run fill ~-10 ~-5 ~-10 ~10 ~5 ~10 air replace nether_portal
execute as @e[type=ender_pearl] at @s run fill ~-7 ~-15 ~-7 ~7 ~20 ~7 air replace end_portal

execute as @a[tag=selecting] at @s anchored eyes run tp @e[type=item_display,tag=classimage,limit=1,sort=nearest] ^ ^ ^0.5 facing ~ ~1.5 ~

#stores current xp, sets the gain of xp = to current - previous, adds gain to xpforlevel, sets previous to current
execute as @a run scoreboard players operation @s xpgain = @s currentXP
execute as @a run scoreboard players operation @s xpgain -= @s prevXP
execute as @a[scores={xpgain=1..}] run scoreboard players operation @s xpforlevel += @s xpgain
execute as @a run scoreboard players operation @s prevXP = @s currentXP

#bloodrage stuff but same
execute as @a[scores={currentdamage=0..}] run scoreboard players operation @s damagegain = @s currentdamage
execute as @a[scores={currentdamage=0..}] run scoreboard players operation @s damagegain -= @s prevdamage
execute as @a[scores={damagegain=1..,currentdamage=0..}] run scoreboard players operation @s damagetrack += @s damagegain
execute as @a[scores={currentdamage=0..}] run scoreboard players operation @s prevdamage = @s currentdamage

#sneaktime stuff but same + sets to 0 if inactivity and triggers sit function if sneak > 150 (7.5 secs)
execute as @a[scores={sneakgain=0}] run scoreboard players set @s sneaktrack 0
execute as @a[scores={currentsneak=0..}] run scoreboard players operation @s sneakgain = @s currentsneak
execute as @a[scores={currentsneak=0..}] run scoreboard players operation @s sneakgain -= @s prevsneak
execute as @a[scores={sneakgain=1..,currentsneak=0..}] run scoreboard players operation @s sneaktrack += @s sneakgain
execute as @a[scores={currentsneak=0..}] run scoreboard players operation @s prevsneak = @s currentsneak
execute as @a[scores={sneaktrack=150..,sneakgain=0}] at @s run function manarune:sitting/sitstart

#info
scoreboard players set @a[scores={infoselect=1}] levelinfo 0
execute as @a[scores={infoselect=1}] run tellraw @s '[Info] §7Welcome to Mana Rune. If you forget something or need help, press G to look at all §r[Info] §7messages or other useful things.'
execute as @a[scores={infoselect=1}] run function manarune:infosystem


execute as @a[scores={infoselect=2},tag=!classed] run tellraw @s "[Info] §7You are currently Unclassed."
execute as @a[scores={infoselect=2},tag=acolyte] run tellraw @s '[Info] §6 You have chosen to be an Acolyte. This class focusses on divine power, religion, and amulets to focus divine will.'
execute as @a[scores={infoselect=2},tag=archer] run dialog show @s manarune:archer_dialogs/basic
execute as @a[scores={infoselect=2},tag=warrior] run dialog show @s manarune:warrior_dialogs/basic
execute as @a[scores={infoselect=2},tag=cleric] run dialog show @s manarune:cleric_dialogs/basic
execute as @a[scores={infoselect=2},tag=wizard] run tellraw @s "[Info] §d You have chosen to be a Wizard. This class focusses on arcane power, mastery of mana, and the use of wands. Infact, with your mastery of mana, you can use wands better than any class that doesn't have focussed mana"


execute as @a[scores={infoselect=10},tag=archer] run tellraw @s "[Info] §3 You have chosen to be an Archer. This class focusses on powerfull bows and arrows to target far enemies.  You begin to inherit knowledge from your anscestors. Press 'G' to look at new information."
execute as @a[scores={infoselect=11,level=7..},tag=archer] run dialog show @s manarune:archer_dialogs/crafting
execute as @a[scores={infoselect=10},tag=warrior] run tellraw @s "[Info] §4 You have chosen to be a Warrior. This class focusses on pure mele combat and phisical prowess. You begin to inherit knowledge from your anscestors. Press 'G' to look at new information."
execute as @a[scores={infoselect=11,level=7..},tag=warrior] run dialog show @s manarune:warrior_dialogs/crafting
execute as @a[scores={infoselect=10},tag=cleric] run tellraw @s "[Info] §5 You have chosen to be a Cleric. This class focusses on healing and conplex potions, as well as the use of wands. You have focussed mana and a mastery of wands above all classes that don't have foccused mana. Press 'G' to look at new information."
execute as @a[scores={infoselect=11,level=7..},tag=cleric] run dialog show @s manarune:cleric_dialogs/crafting

execute as @a[scores={infoselect=100}] store result storage minecraft:completion player int 1 run scoreboard players get @s completion
execute as @a[scores={infoselect=100}] run function manarune:completion with storage minecraft:completion
execute as @a[scores={infoselect=100}] run data remove storage minecraft:completion player

scoreboard players reset @a[scores={infoselect=1..}] infoselect

#archer amulet
execute as @a[scores={level=7..},tag=archer] if items entity @s weapon.offhand diamond[enchantments={unbreaking:14}] at @s as @e[type=#minecraft:arrows,distance=1.5..1.8] run data modify entity @s NoGravity set value 1b
execute as @a[scores={level=7..},tag=acolyte] if items entity @s weapon.offhand diamond[enchantments={unbreaking:14}] at @s as @e[type=#minecraft:arrows,distance=1.5..1.8] run data modify entity @s NoGravity set value 1b
execute as @a[nbt={OnGround:1b},scores={level=13..},tag=archer] at @s if items entity @s weapon.offhand diamond[enchantments={unbreaking:16}] if entity @e[type=#arrows,distance=1.5..1.8,limit=1,sort=nearest] run ride @s mount @e[type=#arrows,distance=1.5..1.8,limit=1,sort=nearest]
execute as @e[type=wind_charge] unless entity @a[distance=..500] run kill @s
execute as @e[type=#arrows] unless entity @a[distance=..500] run kill @s

execute as @a[tag=!archer] at @s if items entity @s weapon.mainhand bow[custom_data={greatbow1:1b}] as @e[type=#minecraft:arrows,distance=1.5..1.8] run kill @s
execute as @a[tag=!archer] at @s if items entity @s weapon.mainhand bow[custom_data={greatbow2:1b}] as @e[type=#minecraft:arrows,distance=1.5..1.8] run kill @s
kill @e[type=#arrows,tag=greatarrow,nbt={inGround:1b}] 

#cleric pots
execute as @a[tag=!reach] if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"effects":{"minecraft:luck":{"amplifier":255}}}} run schedule function manarune:floorcrafting/cleric/reachremove 180s
execute as @a[tag=!reach] if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"effects":{"minecraft:luck":{"amplifier":255}}}} run function manarune:floorcrafting/cleric/reachadd
execute as @a if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"effects":{"minecraft:luck":{"amplifier":254}}}} at @s run spreadplayers ~ ~ 0 1 false @s


function manarune:wandstuff/planeswitch
